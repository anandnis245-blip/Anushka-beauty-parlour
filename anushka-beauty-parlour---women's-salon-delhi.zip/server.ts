import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini SDK with User-Agent header as required
const rawApiKey = process.env.GEMINI_API_KEY;
const hasValidApiKey = Boolean(rawApiKey && rawApiKey !== 'MY_GEMINI_API_KEY' && rawApiKey.trim().length > 10);

let ai: GoogleGenAI | null = null;
if (hasValidApiKey && rawApiKey) {
  ai = new GoogleGenAI({
    apiKey: rawApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// AI Beauty Parlour Chatbot Endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    const systemInstruction = `You are "Anushka AI", the official virtual beauty concierge and aesthetic consultant for "Anushka Beauty Parlour" (Exclusive Women's Parlour).
Business Information:
- Salon Name: Anushka Beauty Parlour
- Tagline: "The salon for your beauty"
- Exclusivity: Strictly a Women's Parlour (safe, relaxing, hygienic, private luxury ambience for women).
- Address: B-57 New Gupta Colony, North Delhi, 110009.
- Timings: Open all days of the week, Monday to Sunday, from 10:00 AM to 8:30 PM.
- Contact Number: 9278637482
- WhatsApp: 9278637482 (Direct link available on site)
- Instagram: https://www.instagram.com/anushka_beauty_parlou?dlrf=MTRyb2Z3dmo4bzE1eA==
- Facebook: https://www.facebook.com/share/1HNLdm4zsU/
- Directions / Google Map: https://maps.app.goo.gl/9yVNxjCmQPhPZNYP8
- Areas Served Nearby: New Gupta Colony, Model Town, Vijay Nagar, GTB Nagar, Hudson Lane, Roop Nagar, Kamla Nagar, North Delhi, Shakti Nagar, Kingsway Camp, Civil Lines, Patel Chest, etc.

Key Highlights & Why Choose Us:
1. We care deeply about your skin and customize every treatment to your skin type.
2. We provide what you want and genuinely care about your satisfaction.
3. Only high-quality premium branded products are used (no harsh or duplicate cosmetics).
4. Highly experienced professional makeup artists and nail artists are available.

Facilities Available:
- Makeovers: Glamorous party makeovers, engagement looks, reception glam, saree & lehenga draping, hairstyle matching.
- Bridal Makeups: HD & Airbrush Bridal Looks, traditional Indian bridal, contemporary pastel bridal, pre-bridal glow packages.
- Skin Treatments: Deep cleansing, hydrating glow facials, anti-acne therapy, brightening peel, anti-aging, pigmentation treatments.
- Beautiful Nail Arts & Nail Treatments: Designer nail art, gel extensions, acrylic nail extensions, chrome finishes, 3D stones, French tips, nail strengthening and cuticle care.
- Facial Cleanup: Organic cleanup, gold glow facial, fruit facial, herbal detan cleanup, oxygenating facials.
- Hair Care & Hair Designs: Keratin treatments, hair spa, rebonding, smoothening, bridal hairstyles, soft curls, blowdry, deep conditioning.

Pricing policy:
- Do not mention specific numerical prices, as pricing varies based on customized consultations, hair length, and bridal packages.
- Always warmly invite the customer to connect directly via Call or WhatsApp on 9278637482 or visit us at B-57 New Gupta Colony for personalized consultation and bookings.

Tone & Persona:
- Warm, polite, courteous, aesthetic, professional, and welcoming.
- You understand English, Hindi, and Hinglish naturally. Respond in the language the customer uses.
- Keep answers concise (2-4 sentences max per reply), helpful, and always offer assistance to book or guide directions.`;

    if (ai) {
      try {
        const conversationContents: any[] = [];
        if (Array.isArray(history) && history.length > 0) {
          for (const item of history.slice(-6)) {
            conversationContents.push({
              role: item.role === 'user' ? 'user' : 'model',
              parts: [{ text: item.text }],
            });
          }
        }
        conversationContents.push({
          role: 'user',
          parts: [{ text: message }],
        });

        // Race with a 3500ms timeout for ultra-fast response
        const timeoutPromise = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('AI response timeout')), 3500)
        );

        const geminiPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: conversationContents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        const response = await Promise.race([geminiPromise, timeoutPromise]);
        const reply = response.text || 'Welcome to Anushka Beauty Parlour! How can I assist you today with our bridal makeups, nail arts, skin treatments, or hair care? You can also reach us directly at 9278637482.';
        res.json({ reply });
        return;
      } catch (aiErr: any) {
        console.warn('Gemini invocation bypassed or timed out, using fallback:', aiErr?.message);
      }
    }

    // Smart contextual fallback
    const lower = message.toLowerCase();
    let fallbackReply = `Welcome to Anushka Beauty Parlour! We are a dedicated Women's Parlour at B-57 New Gupta Colony, North Delhi. We are open today from 10:00 AM to 8:30 PM. You can reach our beauty experts directly at 9278637482 or via WhatsApp for appointments.`;

    if (lower.includes('bridal') || lower.includes('wedding') || lower.includes('shaadi') || lower.includes('makeover')) {
      fallbackReply = `Congratulations on your upcoming special occasion! At Anushka Beauty Parlour, our experienced artists specialize in HD and Airbrush Bridal Makeups, pre-bridal skin prep, saree/lehenga draping, and designer hair styling. Please call or WhatsApp us on 9278637482 to consult and reserve your bridal date!`;
    } else if (lower.includes('nail') || lower.includes('extension') || lower.includes('art')) {
      fallbackReply = `We offer gorgeous Designer Nail Arts, Gel Extensions, Acrylics, French tips, and nourishing cuticle treatments! Check out our latest nail designs on our Instagram (@anushka_beauty_parlou) or visit us at B-57 New Gupta Colony.`;
    } else if (lower.includes('hair') || lower.includes('keratin') || lower.includes('spa') || lower.includes('smoothening')) {
      fallbackReply = `For your hair, we provide Keratin treatments, rejuvenating hair spa, rebonding, smoothening, and creative bridal hairstyles using only high-quality gentle products. Walk into B-57 New Gupta Colony or call 9278637482 to consult.`;
    } else if (lower.includes('skin') || lower.includes('facial') || lower.includes('cleanup') || lower.includes('glow') || lower.includes('acne')) {
      fallbackReply = `We care deeply about your skin! We offer Gold Glow Facials, Organic Cleanups, anti-tan, and customized skin treatments tailored specifically to your skin type. Call 9278637482 to book your relaxing session.`;
    } else if (lower.includes('timing') || lower.includes('open') || lower.includes('time') || lower.includes('close')) {
      fallbackReply = `Anushka Beauty Parlour is open all 7 days of the week from 10:00 AM to 8:30 PM at B-57 New Gupta Colony. We look forward to pampering you!`;
    } else if (lower.includes('address') || lower.includes('where') || lower.includes('location') || lower.includes('route') || lower.includes('map')) {
      fallbackReply = `We are conveniently located at B-57 New Gupta Colony, North Delhi (near Model Town, Vijay Nagar & GTB Nagar). You can click the 'Get Directions' button on our website or open https://maps.app.goo.gl/9yVNxjCmQPhPZNYP8!`;
    } else if (lower.includes('price') || lower.includes('cost') || lower.includes('rate') || lower.includes('charge')) {
      fallbackReply = `We customize every service based on your specific hair/skin needs and preferences using top-quality products. For personalized quotes and best bridal packages, please message us on WhatsApp or call 9278637482!`;
    }

    res.json({ reply: fallbackReply });
  } catch (error: any) {
    console.error('Chat endpoint error:', error);
    res.status(500).json({
      error: 'Unable to process your request at this moment. Please call us at 9278637482 for instant assistance.',
    });
  }
});

// Setup Vite or static serving
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}

startServer();
