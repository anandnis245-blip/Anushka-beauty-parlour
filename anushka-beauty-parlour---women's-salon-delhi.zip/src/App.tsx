import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ServiceSearchSection } from './components/ServiceSearchSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { Facilities } from './components/Facilities';
import { InstagramShowcase } from './components/InstagramShowcase';
import { LocationDirections } from './components/LocationDirections';
import { NearbyAreasSeo } from './components/NearbyAreasSeo';
import { AiChatbot } from './components/AiChatbot';
import { AppointmentModal } from './components/AppointmentModal';
import { OpenHoursModal } from './components/OpenHoursModal';
import { SearchModal } from './components/SearchModal';
import { MobileQuickBar } from './components/MobileQuickBar';
import { Footer } from './components/Footer';
import { MessageCircle, Sparkles, Search, Clock, Instagram, Facebook } from 'lucide-react';
import { PARLOUR_INFO } from './data/parlourData';

export default function App() {
  const [chatOpen, setChatOpen] = useState(false);
  const [chatQuery, setChatQuery] = useState('');
  const [bookingOpen, setBookingOpen] = useState(false);
  const [hoursOpen, setHoursOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleOpenSearch = (initial?: string) => {
    if (initial) {
      setSearchQuery(initial);
    }
    setSearchOpen(true);
  };

  const handleOpenChat = (query?: string) => {
    if (query) {
      setChatQuery(query);
    }
    setChatOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-stone-900 flex flex-col selection:bg-amber-300 selection:text-stone-950 relative">
      {/* Lady portrait prominently woven into the website background theme on the left side */}
      <div className="fixed top-14 left-0 w-[360px] sm:w-[480px] lg:w-[640px] h-screen pointer-events-none select-none overflow-hidden z-0 opacity-[0.16] sm:opacity-[0.20] lg:opacity-[0.24]">
        <img
          src={PARLOUR_INFO.bgImage}
          alt="Anushka Beauty Parlour Theme Background"
          className="w-full h-full object-cover object-left-top filter contrast-110 saturate-120"
        />
        {/* Soft edge gradients blending naturally into the white light cream background towards right */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#FAF7F2]/40 to-[#FAF7F2]" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#FAF7F2]/40 via-transparent to-[#FAF7F2]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#FAF7F2]/80 via-transparent to-transparent" />
      </div>

      {/* Header with restored golden sparkle crest logo and Search shortcut */}
      <Header
        onOpenBooking={() => setBookingOpen(true)}
        onOpenChat={() => handleOpenChat()}
        onOpenSearch={() => handleOpenSearch()}
        onOpenHours={() => setHoursOpen(true)}
      />

      {/* Main Content */}
      <main className="flex-1 relative z-10">
        {/* Centered Hero Section with Interactive Search Box */}
        <Hero
          onOpenBooking={() => setBookingOpen(true)}
          onOpenChat={() => handleOpenChat()}
          onOpenSearch={(query) => handleOpenSearch(query)}
          onOpenHours={() => setHoursOpen(true)}
        />

        {/* Dedicated Interactive Service & Treatment Search Section */}
        <ServiceSearchSection
          onOpenBooking={() => setBookingOpen(true)}
          onOpenChat={(q) => handleOpenChat(q)}
        />

        {/* Why Choose Us */}
        <WhyChooseUs />

        {/* Special Beauty Facilities with Pictures in front of them */}
        <Facilities />

        {/* Instagram Portfolio Showcase */}
        <InstagramShowcase />

        {/* Location, Directions & Contact */}
        <LocationDirections />

        {/* Nearby Areas Served & SEO Directory */}
        <NearbyAreasSeo />
      </main>

      {/* Footer with restored golden sparkle crest logo */}
      <Footer />

      {/* Mobile Sticky Quick Action Bar with Search, Call, WhatsApp, Route, AI */}
      <MobileQuickBar
        onOpenChat={() => handleOpenChat()}
        onOpenSearch={() => handleOpenSearch()}
      />

      {/* Side Floating Social Tab Box (WhatsApp, Instagram, Facebook for easy profile view) */}
      <div className="fixed left-0 top-1/2 -translate-y-1/2 z-40 hidden sm:flex flex-col gap-2 p-1.5 rounded-r-2xl bg-white/95 border-y border-r border-[#DFC899] shadow-2xl backdrop-blur-md">
        <a
          href={PARLOUR_INFO.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-md hover:scale-110 active:scale-95 transition-all group relative flex items-center justify-center"
          title="WhatsApp: Chat with Anushka Beauty Parlour"
        >
          <MessageCircle className="w-4 h-4 fill-white/20" />
          <span className="absolute left-full ml-2 px-2.5 py-1 rounded-lg bg-stone-900 text-white text-[11px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-md">
            WhatsApp
          </span>
        </a>
        <a
          href={PARLOUR_INFO.instagramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="p-2.5 rounded-xl bg-gradient-to-tr from-pink-600 via-rose-500 to-amber-600 text-white shadow-md hover:scale-110 active:scale-95 transition-all group relative flex items-center justify-center"
          title="Instagram Profile: @anushka_beauty_parlou"
        >
          <Instagram className="w-4 h-4" />
          <span className="absolute left-full ml-2 px-2.5 py-1 rounded-lg bg-stone-900 text-white text-[11px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-md">
            Instagram
          </span>
        </a>
        <a
          href={PARLOUR_INFO.facebookUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="p-2.5 rounded-xl bg-[#1877F2] hover:bg-[#166fe5] text-white shadow-md hover:scale-110 active:scale-95 transition-all group relative flex items-center justify-center"
          title="Facebook Profile: Anushka Beauty Parlour"
        >
          <Facebook className="w-4 h-4 fill-white" />
          <span className="absolute left-full ml-2 px-2.5 py-1 rounded-lg bg-stone-900 text-white text-[11px] font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-md">
            Facebook
          </span>
        </a>
      </div>

      {/* Floating Action Buttons for Desktop */}
      <div className="hidden lg:flex fixed bottom-6 right-6 z-40 flex-col items-end gap-2.5">
        {/* Open Timings Schedule Floating Button */}
        <button
          onClick={() => setHoursOpen(true)}
          className="group flex items-center gap-2 px-3.5 py-2 rounded-full bg-white/95 border border-[#DFC899] hover:border-[#B8860B] text-stone-800 font-bold text-xs shadow-md shadow-amber-950/10 hover:scale-105 transition-all cursor-pointer backdrop-blur-sm"
          title="Parlour Open Schedule: 10 AM - 8:30 PM (All 7 Days)"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <Clock className="w-3.5 h-3.5 text-[#B8860B]" />
          <span>Open 10 AM – 8:30 PM</span>
        </button>

        {/* Search Services Floating Button */}
        <button
          onClick={() => handleOpenSearch()}
          className="group flex items-center gap-2 px-4 py-2.5 rounded-full bg-white border border-[#DFC899] hover:border-[#B8860B] text-[#784A0E] font-bold text-xs shadow-lg shadow-amber-950/10 hover:scale-105 transition-all cursor-pointer"
          title="Search all salon services (Cmd+K)"
        >
          <Search className="w-4 h-4 text-[#B8860B]" />
          <span>Search Services</span>
          <kbd className="text-[10px] bg-amber-50 px-1 py-0.2 rounded border border-[#DFC899] text-stone-500 font-mono">⌘K</kbd>
        </button>

        {/* Social Connect Tab Box: WhatsApp, Instagram & Facebook tabs beside each other */}
        <div className="flex items-center gap-1.5 p-1.5 rounded-full bg-white/95 border border-[#DFC899] shadow-xl shadow-amber-950/15 backdrop-blur-md">
          {/* WhatsApp Tab */}
          <a
            href={PARLOUR_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xs hover:scale-105 active:scale-95 transition-all"
            title="Chat with Anushka Beauty Parlour on WhatsApp"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>WhatsApp</span>
          </a>

          {/* Instagram Tab Box beside WhatsApp */}
          <a
            href={PARLOUR_INFO.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-gradient-to-r from-pink-600 via-rose-500 to-amber-600 hover:opacity-90 text-white font-bold text-xs shadow-xs hover:scale-105 active:scale-95 transition-all"
            title="View Makeups & Nail Arts on Instagram (@anushka_beauty_parlou)"
          >
            <Instagram className="w-4 h-4" />
            <span>Instagram</span>
          </a>

          {/* Facebook Tab Box beside WhatsApp */}
          <a
            href={PARLOUR_INFO.facebookUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-[#1877F2] hover:bg-[#166fe5] text-white font-bold text-xs shadow-xs hover:scale-105 active:scale-95 transition-all"
            title="Visit Anushka Beauty Parlour on Facebook"
          >
            <Facebook className="w-4 h-4 fill-white" />
            <span>Facebook</span>
          </a>
        </div>

        {/* AI Beauty Concierge Floating Button */}
        <button
          onClick={() => handleOpenChat()}
          className="group flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-[#D4AF37] via-[#E8C15A] to-[#B8860B] hover:from-[#DFC04E] hover:to-[#A37409] text-stone-950 font-bold text-xs shadow-xl shadow-amber-950/20 hover:scale-105 transition-all cursor-pointer"
          title="Ask AI Beauty Concierge"
        >
          <div className="w-5 h-5 rounded-full bg-stone-950/15 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-stone-950" />
          </div>
          <span>AI Beauty Assistant</span>
          <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping" />
        </button>
      </div>

      {/* Open Hours Modal */}
      <OpenHoursModal
        isOpen={hoursOpen}
        onClose={() => setHoursOpen(false)}
        onOpenBooking={() => {
          setHoursOpen(false);
          setBookingOpen(true);
        }}
      />

      {/* Global Search Modal */}
      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        initialQuery={searchQuery}
        onOpenChatWithQuery={(q) => handleOpenChat(q)}
      />

      {/* AI Chatbot Dialog */}
      <AiChatbot
        isOpen={chatOpen}
        onClose={() => setChatOpen(false)}
        initialQuery={chatQuery}
      />

      {/* Appointment / Booking Modal */}
      <AppointmentModal isOpen={bookingOpen} onClose={() => setBookingOpen(false)} />
    </div>
  );
}
