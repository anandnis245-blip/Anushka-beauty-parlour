export interface ParlourStatus {
  isOpen: boolean;
  statusText: string;
  nextEventText: string;
  detailText: string;
  schedule: { day: string; hours: string; isOpen: boolean }[];
}

export function getParlourStatus(): ParlourStatus {
  // Compute time in Indian Standard Time (UTC + 5 hours 30 mins)
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const istOffset = 5.5 * 60 * 60000;
  const istTime = new Date(utc + istOffset);

  const hours = istTime.getHours();
  const minutes = istTime.getMinutes();
  const currentTotalMinutes = hours * 60 + minutes;

  // 10:00 AM is 600 minutes
  const openTimeMinutes = 10 * 60;
  // 8:30 PM is 20 * 60 + 30 = 1230 minutes
  const closeTimeMinutes = 20 * 60 + 30;

  const isCurrentlyInParlourHours =
    currentTotalMinutes >= openTimeMinutes && currentTotalMinutes < closeTimeMinutes;

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const todayName = days[istTime.getDay()];

  const schedule = [
    { day: 'Monday', hours: '10:00 AM – 8:30 PM', isOpen: true },
    { day: 'Tuesday', hours: '10:00 AM – 8:30 PM', isOpen: true },
    { day: 'Wednesday', hours: '10:00 AM – 8:30 PM', isOpen: true },
    { day: 'Thursday', hours: '10:00 AM – 8:30 PM', isOpen: true },
    { day: 'Friday', hours: '10:00 AM – 8:30 PM', isOpen: true },
    { day: 'Saturday', hours: '10:00 AM – 8:30 PM', isOpen: true },
    { day: 'Sunday', hours: '10:00 AM – 8:30 PM', isOpen: true },
  ];

  if (isCurrentlyInParlourHours) {
    return {
      isOpen: true,
      statusText: 'Open Now',
      nextEventText: '10:00 AM – 8:30 PM (All 7 Days)',
      detailText: 'Parlour doors are open for walk-ins & appointments until 8:30 PM today.',
      schedule,
    };
  } else if (currentTotalMinutes < openTimeMinutes) {
    return {
      isOpen: true,
      statusText: 'Open Today',
      nextEventText: 'Opens at 10:00 AM today (10 AM – 8:30 PM)',
      detailText: 'Open all 7 days. Accepting WhatsApp bookings now, parlour opens at 10:00 AM.',
      schedule,
    };
  } else {
    return {
      isOpen: true,
      statusText: 'Open Daily',
      nextEventText: 'Open 10:00 AM – 8:30 PM (All 7 Days)',
      detailText: 'Open all 7 days. Parlour opens tomorrow at 10:00 AM. 24/7 WhatsApp booking active.',
      schedule,
    };
  }
}

export function openDirections(userCurrentMapUrl: string = 'https://maps.app.goo.gl/9yVNxjCmQPhPZNYP8') {
  if ('geolocation' in navigator) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const url = `https://www.google.com/maps/dir/?api=1&origin=${latitude},${longitude}&destination=B-57+New+Gupta+Colony+Delhi+110009`;
        window.open(url, '_blank', 'noopener,noreferrer');
      },
      () => {
        window.open(userCurrentMapUrl, '_blank', 'noopener,noreferrer');
      },
      { timeout: 7000 }
    );
  } else {
    window.open(userCurrentMapUrl, '_blank', 'noopener,noreferrer');
  }
}
