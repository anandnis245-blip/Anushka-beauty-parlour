import React, { useState, useEffect } from 'react';
import { Phone, MessageCircle, MapPin, Sparkles, Menu, X, Heart, Search, Instagram, Facebook } from 'lucide-react';
import { PARLOUR_INFO } from '../data/parlourData';
import { getParlourStatus } from '../utils/timeHelper';

interface HeaderProps {
  onOpenBooking: () => void;
  onOpenChat: () => void;
  onOpenSearch: () => void;
  onOpenHours?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenBooking, onOpenChat, onOpenSearch, onOpenHours }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [status, setStatus] = useState(getParlourStatus());

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll);

    // Global keyboard shortcut for search (Cmd+K / Ctrl+K)
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        onOpenSearch();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    const interval = setInterval(() => {
      setStatus(getParlourStatus());
    }, 60000);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('keydown', handleKeyDown);
      clearInterval(interval);
    };
  }, [onOpenSearch]);

  return (
    <>
      {/* Top cream micro-announcement banner */}
      <div className="bg-[#F5EFE6] border-b border-[#E5DAC6] text-xs py-2 px-4 text-stone-700 flex flex-wrap justify-between items-center gap-2">
        <div className="max-w-7xl mx-auto w-full flex flex-wrap justify-between items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white border border-[#DFC899] text-[#8C5810] font-semibold text-[11px] uppercase tracking-wider shadow-xs">
              <Heart className="w-3 h-3 text-[#B8860B] fill-[#B8860B]" />
              Women's Parlour
            </span>
            <span className="hidden sm:inline text-stone-400">•</span>
            <span className="hidden sm:inline text-stone-700 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-[#B8860B]" />
              {PARLOUR_INFO.addressShort} (North Delhi)
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium">
            <button
              onClick={onOpenHours}
              className="flex items-center gap-1.5 hover:opacity-85 transition-opacity cursor-pointer text-left"
              title="Click to view weekly open timings schedule"
            >
              <span className={`w-2 h-2 rounded-full ${status.isOpen ? 'bg-emerald-500 animate-pulse' : 'bg-amber-600'}`} />
              <span className={status.isOpen ? 'text-emerald-800 font-bold' : 'text-amber-800 font-bold'}>
                {status.statusText}
              </span>
              <span className="hidden md:inline text-stone-600 text-[11px]">
                ({status.nextEventText})
              </span>
            </button>
            <a
              href={`tel:${PARLOUR_INFO.phone}`}
              className="hidden lg:flex items-center gap-1 text-[#8C5810] hover:text-[#5E3A06] transition-colors font-semibold"
            >
              <Phone className="w-3 h-3 text-[#B8860B]" />
              <span>{PARLOUR_INFO.phoneFormatted}</span>
            </a>

            {/* Quick Instagram and Facebook header profile links */}
            <div className="hidden xl:flex items-center gap-2.5 pl-3 border-l border-[#E5DAC6]">
              <a
                href={PARLOUR_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-pink-700 hover:text-pink-900 font-bold transition-colors"
                title="Instagram Profile (@anushka_beauty_parlou)"
              >
                <Instagram className="w-3.5 h-3.5 text-pink-600" />
                <span>Instagram</span>
              </a>
              <span className="text-stone-300">•</span>
              <a
                href={PARLOUR_INFO.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-[#1877F2] hover:text-blue-800 font-bold transition-colors"
                title="Facebook Page"
              >
                <Facebook className="w-3.5 h-3.5 fill-[#1877F2]" />
                <span>Facebook</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main sticky navigation in white light cream luxury style */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#FAF7F2]/95 backdrop-blur-md shadow-md shadow-amber-950/5 border-b border-[#E8DEC8] py-2.5'
            : 'bg-[#FAF7F2]/90 backdrop-blur-sm border-b border-[#ECE3D4] py-3.5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
          {/* Brand Logo with golden-yellow shiny style and stylish tagline */}
          <a href="#" className="group flex flex-col">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-tr from-[#D4AF37] via-[#F3CE72] to-[#AA771C] p-[1.5px] shadow-sm group-hover:scale-105 transition-transform shrink-0">
                <div className="w-full h-full bg-[#FFFDF9] rounded-full flex items-center justify-center">
                  <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-[#B8860B]" />
                </div>
              </div>
              <span className="font-title text-xl sm:text-2xl md:text-3xl font-extrabold uppercase tracking-wide gold-shiny-text">
                Anushka Beauty Parlour
              </span>
            </div>
            <span className="font-tagline text-lg sm:text-xl md:text-2xl gold-shiny-subtext ml-11 sm:ml-12 -mt-1 font-normal tracking-wide">
              The salon for your beauty
            </span>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-7 text-sm font-semibold text-stone-700">
            <a href="#search-services" className="hover:text-[#B8860B] transition-colors flex items-center gap-1.5 text-[#784A0E]">
              <Search className="w-3.5 h-3.5 text-[#B8860B]" />
              <span>Search Services</span>
            </a>
            <a href="#facilities" className="hover:text-[#B8860B] transition-colors">
              Facilities
            </a>
            <a href="#why-choose-us" className="hover:text-[#B8860B] transition-colors">
              Why Choose Us
            </a>
            <a href="#instagram-showcase" className="hover:text-[#B8860B] transition-colors">
              Instagram Looks
            </a>
            <a href="#location-directions" className="hover:text-[#B8860B] transition-colors">
              Address & Map
            </a>
            <a href="#areas-served" className="hover:text-[#B8860B] transition-colors">
              Areas Served
            </a>
          </nav>

          {/* Desktop CTAs & Search Trigger */}
          <div className="hidden sm:flex items-center gap-2">
            {/* Quick Search Trigger Button */}
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-white border border-[#DFC899] text-[#784A0E] hover:border-[#B8860B] hover:bg-amber-50/60 transition-all text-xs font-bold shadow-xs cursor-pointer group"
              title="Search services, bridal makeup, nail art (Cmd+K)"
            >
              <Search className="w-3.5 h-3.5 text-[#B8860B] group-hover:scale-110 transition-transform" />
              <span>Search</span>
              <kbd className="hidden md:inline text-[9px] px-1 py-0.2 rounded bg-amber-50 border border-[#DFC899] text-stone-500 font-mono">⌘K</kbd>
            </button>

            <a
              href={`tel:${PARLOUR_INFO.phone}`}
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-white border border-[#DFC899] text-[#784A0E] hover:border-[#B8860B] hover:bg-[#FFFDF9] transition-all text-xs font-bold shadow-xs"
              title="Call Anushka Beauty Parlour"
            >
              <Phone className="w-3.5 h-3.5 text-[#B8860B] fill-[#B8860B]/20" />
              <span>Call</span>
            </a>

            <a
              href={PARLOUR_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white transition-all text-xs font-bold shadow-sm hover:scale-105 active:scale-95"
              title="Direct WhatsApp Chat"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white/20" />
              <span>WhatsApp</span>
            </a>

            {/* Instagram Profile Tab Box beside WhatsApp */}
            <a
              href={PARLOUR_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-gradient-to-r from-pink-600 via-rose-500 to-amber-600 hover:opacity-90 text-white transition-all text-xs font-bold shadow-sm hover:scale-105 active:scale-95"
              title="View Makeups & Nail Arts on Instagram (@anushka_beauty_parlou)"
            >
              <Instagram className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">Instagram</span>
            </a>

            {/* Facebook Profile Tab Box beside WhatsApp */}
            <a
              href={PARLOUR_INFO.facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-[#1877F2] hover:bg-[#166fe5] text-white transition-all text-xs font-bold shadow-sm hover:scale-105 active:scale-95"
              title="Visit Anushka Beauty Parlour on Facebook"
            >
              <Facebook className="w-3.5 h-3.5 fill-white" />
              <span className="hidden xl:inline">Facebook</span>
            </a>

            <button
              onClick={onOpenChat}
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-gradient-to-r from-[#D4AF37] via-[#E8C15A] to-[#B8860B] hover:from-[#DFC04E] hover:to-[#A37409] text-stone-950 font-bold text-xs transition-all shadow-sm cursor-pointer hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Bot</span>
            </button>
          </div>

          {/* Mobile Search & hamburger buttons */}
          <div className="flex items-center gap-1 lg:hidden">
            <button
              onClick={onOpenSearch}
              className="p-2 text-[#784A0E] hover:text-[#B8860B] focus:outline-none"
              aria-label="Open search"
            >
              <Search className="w-5 h-5 text-[#B8860B]" />
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-stone-700 hover:text-[#B8860B] focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FAF7F2] border-b border-[#E5DAC6] px-5 py-4 space-y-3 animate-in fade-in slide-in-from-top duration-200 shadow-xl">
            {/* Quick search input inside mobile drawer */}
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSearch();
              }}
              className="w-full flex items-center gap-2.5 p-2.5 rounded-xl bg-white border border-[#DFC899] text-stone-600 text-xs font-medium text-left shadow-2xs"
            >
              <Search className="w-4 h-4 text-[#B8860B]" />
              <span>Search services, nail art, keratin...</span>
            </button>

            <div className="flex flex-col gap-2.5 text-sm font-semibold border-b border-[#ECE3D4] pb-3 text-stone-800">
              <a
                href="#search-services"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#B8860B] py-1 flex items-center gap-2 text-[#784A0E]"
              >
                <Search className="w-4 h-4 text-[#B8860B]" />
                <span>Search Beauty Services & Treatments</span>
              </a>
              <a
                href="#facilities"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#B8860B] py-1"
              >
                Beauty Facilities & Photos
              </a>
              <a
                href="#why-choose-us"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#B8860B] py-1"
              >
                Why Choose Us
              </a>
              <a
                href="#instagram-showcase"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#B8860B] py-1"
              >
                Instagram Photos & Portfolio
              </a>
              <a
                href="#location-directions"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#B8860B] py-1"
              >
                Address, Hours & Route
              </a>
              <a
                href="#areas-served"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#B8860B] py-1"
              >
                Nearby Areas & Local SEO
              </a>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <a
                href={`tel:${PARLOUR_INFO.phone}`}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-white border border-[#DFC899] text-[#784A0E] font-bold text-xs shadow-xs"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Now</span>
              </a>
              <a
                href={PARLOUR_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-emerald-600 text-white font-bold text-xs shadow-xs"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
              <a
                href={PARLOUR_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-gradient-to-r from-pink-600 via-rose-500 to-amber-600 text-white font-bold text-xs shadow-xs"
              >
                <Instagram className="w-3.5 h-3.5" />
                <span>Instagram</span>
              </a>
              <a
                href={PARLOUR_INFO.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-[#1877F2] text-white font-bold text-xs shadow-xs"
              >
                <Facebook className="w-3.5 h-3.5 fill-white" />
                <span>Facebook</span>
              </a>
            </div>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenChat();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-gradient-to-r from-[#D4AF37] via-[#E8C15A] to-[#B8860B] text-stone-950 font-bold text-xs shadow-sm cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Ask AI Beauty Assistant</span>
            </button>
          </div>
        )}
      </header>
    </>
  );
};
