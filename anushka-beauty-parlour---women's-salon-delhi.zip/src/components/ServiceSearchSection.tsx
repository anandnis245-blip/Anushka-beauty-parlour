import React, { useState, useMemo } from 'react';
import {
  Search,
  Sparkles,
  Clock,
  Check,
  MessageCircle,
  Phone,
  Heart,
  X,
  Filter,
  ArrowRight
} from 'lucide-react';
import {
  SEARCHABLE_SERVICES,
  SearchableService,
  PARLOUR_INFO
} from '../data/parlourData';

const CATEGORIES = [
  'All Services',
  'Bridal Makeups',
  'Nail Studio',
  'Skin Care',
  'Facial Cleanup',
  'Hair Care',
  'Occasion Glam',
  'Grooming',
] as const;

const QUICK_TAGS = [
  'HD Bridal',
  'Airbrush',
  'Gel Extensions',
  'Nail Art',
  'Keratin Smoothening',
  'Gold Facial',
  'Fruit Cleanup',
  'Acne Care',
  'Hair Spa',
  'Saree Draping',
];

interface ServiceSearchSectionProps {
  onOpenBooking: () => void;
  onOpenChat: (query?: string) => void;
}

export const ServiceSearchSection: React.FC<ServiceSearchSectionProps> = ({
  onOpenBooking,
  onOpenChat,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All Services');

  const filteredServices = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();

    return SEARCHABLE_SERVICES.filter((svc) => {
      // Category check
      if (selectedCategory !== 'All Services' && svc.category !== selectedCategory) {
        return false;
      }

      // Query check
      if (!q) return true;

      return (
        svc.title.toLowerCase().includes(q) ||
        svc.category.toLowerCase().includes(q) ||
        svc.shortDesc.toLowerCase().includes(q) ||
        svc.idealFor.toLowerCase().includes(q) ||
        svc.keywords.some((k) => k.toLowerCase().includes(q)) ||
        svc.highlights.some((h) => h.toLowerCase().includes(q))
      );
    });
  }, [searchTerm, selectedCategory]);

  return (
    <section id="search-services" className="py-16 md:py-24 relative bg-[#FAF7F2] border-b border-[#ECE3D4]">
      {/* Background warm ambient glows */}
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-amber-200/20 blur-[130px] rounded-full pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-yellow-100/30 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-white border border-[#DFC899] text-[#784A0E] font-semibold text-xs uppercase tracking-widest shadow-2xs">
            <Search className="w-3.5 h-3.5 text-[#B8860B]" />
            Search Salon Catalog
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-wider gold-shiny-text leading-tight">
            SEARCH & EXPLORE BEAUTY SERVICES
          </h2>
          <p className="font-tagline text-3xl sm:text-4xl md:text-5xl gold-shiny-subtext pt-1">
            Find the perfect treatment customized for your skin and hair
          </p>
          <p className="text-stone-600 text-sm sm:text-base max-w-2xl mx-auto font-medium">
            Search our extensive portfolio of bridal makeups, designer nail extensions, organic skin care, facial cleanups, and keratin hair therapies.
          </p>
        </div>

        {/* Central Search Bar Card */}
        <div className="max-w-3xl mx-auto mb-8">
          <div className="relative rounded-2xl p-2 sm:p-2.5 bg-white border-2 border-[#DFC899] shadow-lg shadow-amber-950/5 focus-within:border-[#B8860B] focus-within:ring-4 focus-within:ring-[#D4AF37]/15 transition-all">
            <div className="flex items-center gap-3 px-2 sm:px-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 border border-[#DFC899] flex items-center justify-center shrink-0">
                <Search className="w-5 h-5 text-[#B8860B]" />
              </div>

              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search any service: 'keratin', 'hd bridal', 'nail extension', 'gold facial'..."
                className="flex-1 bg-transparent text-stone-900 placeholder:text-stone-400 font-medium text-sm sm:text-base focus:outline-none py-2"
              />

              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
                  title="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}

              <button
                onClick={() => onOpenChat(searchTerm || 'beauty recommendations')}
                className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#FAF7F2] hover:bg-amber-100/60 border border-[#DFC899] text-[#784A0E] text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
                title="Ask AI beauty assistant"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#B8860B]" />
                <span>Ask AI</span>
              </button>
            </div>
          </div>

          {/* Quick Search Tag Pills */}
          <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
            <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
              Quick Searches:
            </span>
            {QUICK_TAGS.map((tag) => (
              <button
                key={tag}
                onClick={() => {
                  setSearchTerm(tag);
                  setSelectedCategory('All Services');
                }}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  searchTerm.toLowerCase() === tag.toLowerCase()
                    ? 'bg-[#B8860B] text-white shadow-xs'
                    : 'bg-white border border-[#E8DEC8] text-stone-700 hover:border-[#D4AF37] hover:bg-amber-50/50'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Category Filters Carousel/Tabs */}
        <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer shadow-2xs ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#D4AF37] via-[#E8C15A] to-[#B8860B] text-stone-950 font-extrabold shadow-sm'
                  : 'bg-white border border-[#E8DEC8] text-stone-700 hover:border-[#D4AF37] hover:bg-[#FFFDF9]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results Counter Banner */}
        <div className="flex items-center justify-between mb-6 pb-3 border-b border-[#ECE3D4] text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-stone-900">
              Showing {filteredServices.length} {filteredServices.length === 1 ? 'service' : 'services'}
            </span>
            {(searchTerm || selectedCategory !== 'All Services') && (
              <span className="text-stone-500">
                for {searchTerm ? `"${searchTerm}"` : ''}{' '}
                {selectedCategory !== 'All Services' ? `in ${selectedCategory}` : ''}
              </span>
            )}
          </div>

          {(searchTerm || selectedCategory !== 'All Services') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('All Services');
              }}
              className="text-[#8C5810] hover:text-[#5E3A06] font-bold hover:underline cursor-pointer"
            >
              Reset filters
            </button>
          )}
        </div>

        {/* Services Results Grid */}
        {filteredServices.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
            {filteredServices.map((service) => (
              <div
                key={service.id}
                className="group flex flex-col rounded-2xl cream-card overflow-hidden transition-all duration-300 hover:-translate-y-1 bg-white"
              >
                {/* Image */}
                <div className="relative h-52 sm:h-56 overflow-hidden bg-stone-100">
                  <img
                    src={service.imageUrl}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-stone-950/20 to-transparent" />

                  {/* Badges */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
                    <span className="px-2.5 py-1 rounded-full bg-white/95 backdrop-blur-md border border-[#DFC899] text-[#784A0E] text-[11px] font-bold shadow-xs">
                      {service.category}
                    </span>
                    {service.badge && (
                      <span className="px-2.5 py-1 rounded-full bg-amber-500/90 text-white text-[11px] font-bold shadow-xs">
                        {service.badge}
                      </span>
                    )}
                  </div>

                  {/* Duration Badge */}
                  <div className="absolute bottom-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-md text-white text-xs font-semibold">
                    <Clock className="w-3.5 h-3.5 text-[#DFC04E]" />
                    <span>{service.duration}</span>
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-heading text-lg sm:text-xl font-bold text-stone-900 group-hover:text-[#784A0E] transition-colors leading-snug">
                      {service.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-medium">
                      {service.shortDesc}
                    </p>
                  </div>

                  {/* Highlights Bullet List */}
                  <div className="space-y-1.5 pt-2 border-t border-[#F2ECE1]">
                    <p className="text-[11px] font-bold text-[#8C5810] uppercase tracking-wider">
                      Included Highlights:
                    </p>
                    <ul className="space-y-1">
                      {service.highlights.slice(0, 3).map((item, idx) => (
                        <li key={idx} className="flex items-start gap-1.5 text-xs text-stone-700 font-medium">
                          <Check className="w-3.5 h-3.5 text-[#B8860B] shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Ideal For Note */}
                  <div className="p-2.5 rounded-xl bg-[#FAF7F2] border border-[#ECE3D4] text-[11px] text-stone-600 font-medium">
                    <span className="font-bold text-[#784A0E]">Ideal For: </span>
                    {service.idealFor}
                  </div>

                  {/* CTAs */}
                  <div className="pt-2 border-t border-[#ECE3D4] flex items-center gap-2">
                    <a
                      href={`https://wa.me/91${PARLOUR_INFO.phone}?text=Hello%20Anushka%20Beauty%20Parlour%2C%20I%20would%20like%20to%20consult%20and%20book%20an%20appointment%20for%20${encodeURIComponent(
                        service.title
                      )}.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-xs transition-all shadow-xs"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Inquire on WhatsApp</span>
                    </a>
                    <a
                      href={`tel:${PARLOUR_INFO.phone}`}
                      className="p-2.5 rounded-xl bg-white border border-[#DFC899] text-[#784A0E] hover:border-[#B8860B] hover:bg-[#FFFDF9] transition-all shadow-xs"
                      title="Call salon"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#B8860B]" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="py-16 px-4 text-center max-w-lg mx-auto bg-white rounded-2xl border border-[#DFC899] shadow-sm space-y-4">
            <div className="w-14 h-14 rounded-full bg-amber-50 border border-[#DFC899] flex items-center justify-center mx-auto text-[#B8860B]">
              <Search className="w-6 h-6 text-[#B8860B]" />
            </div>
            <div className="space-y-1">
              <h3 className="font-heading text-xl font-bold text-stone-900">
                No services found matching "{searchTerm}"
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 font-medium">
                We cater to all customized bridal packages, designer nail art styles, and skin care requirements. Contact our beauty artists directly!
              </p>
            </div>
            <div className="pt-2 flex flex-col sm:flex-row gap-2.5 justify-center">
              <button
                onClick={() => onOpenChat(searchTerm)}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-stone-950 font-bold text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Ask Anushka AI Concierge</span>
              </button>
              <a
                href={`https://wa.me/91${PARLOUR_INFO.phone}?text=Hello%20Anushka%20Beauty%20Parlour%2C%20I%20am%20looking%20for%20customized%20services%20related%20to%3A%20${encodeURIComponent(
                  searchTerm
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Ask on WhatsApp</span>
              </a>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
