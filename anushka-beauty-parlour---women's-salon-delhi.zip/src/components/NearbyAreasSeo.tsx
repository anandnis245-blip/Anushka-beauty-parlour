import React, { useState } from 'react';
import { MapPin, Search, Navigation, Sparkles, CheckCircle2 } from 'lucide-react';
import { NEARBY_AREAS, SEO_KEYWORDS, PARLOUR_INFO } from '../data/parlourData';
import { openDirections } from '../utils/timeHelper';

export const NearbyAreasSeo: React.FC = () => {
  const [activeArea, setActiveArea] = useState<string>('New Gupta Colony');

  return (
    <section id="areas-served" className="py-16 md:py-24 relative bg-[#FAF7F2] border-b border-[#ECE3D4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-[#DFC899] text-[#784A0E] font-semibold text-xs uppercase tracking-widest shadow-2xs">
            <Search className="w-3.5 h-3.5 text-[#B8860B]" />
            North Delhi Service Reach
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-wider gold-shiny-text leading-tight">
            AREAS SERVED & LOCAL PRESENCE
          </h2>

          <p className="font-tagline text-3xl sm:text-4xl md:text-5xl gold-shiny-subtext pt-1">
            Best beauty parlour nearby you in North Delhi
          </p>

          <p className="text-stone-600 text-sm sm:text-base max-w-2xl mx-auto font-medium">
            Welcoming clients from across North Delhi neighborhoods. Just minutes away from your doorstep with convenient connectivity.
          </p>
        </div>

        {/* Nearby Areas Interactive Grid */}
        <div className="space-y-4 mb-12">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#784A0E] flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#B8860B]" />
              <span>Areas Served Nearby Our Address (B-57 New Gupta Colony)</span>
            </h3>
            <span className="text-xs text-stone-500 hidden sm:inline font-medium">
              Click any location to see details & directions
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {NEARBY_AREAS.map((area) => {
              const isSelected = activeArea === area.name;
              return (
                <button
                  key={area.name}
                  onClick={() => setActiveArea(area.name)}
                  className={`p-3.5 rounded-xl border text-left transition-all duration-200 cursor-pointer ${
                    isSelected
                      ? 'bg-amber-50/90 border-[#D4AF37] text-stone-950 shadow-md shadow-amber-950/10 scale-102 font-semibold'
                      : 'bg-white border-[#E8DEC8] text-stone-700 hover:border-[#D4AF37] hover:bg-[#FFFDF9]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold truncate">{area.name}</span>
                    <MapPin className={`w-3 h-3 ${isSelected ? 'text-[#B8860B]' : 'text-stone-400'}`} />
                  </div>
                  <p className="text-[11px] text-[#8C5810] font-semibold">{area.distance}</p>
                </button>
              );
            })}
          </div>

          {/* Selected Area Highlight Box */}
          {activeArea && (
            <div className="mt-4 p-5 rounded-2xl bg-white border border-[#DFC899] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-50 border border-[#DFC899] text-[#784A0E] text-[11px] font-bold">
                    Serving {activeArea}
                  </span>
                  <span className="text-stone-500 text-xs font-medium">
                    {NEARBY_AREAS.find((a) => a.name === activeArea)?.distance}
                  </span>
                </div>
                <p className="text-sm font-bold text-stone-900">
                  {NEARBY_AREAS.find((a) => a.name === activeArea)?.highlight}
                </p>
                <p className="text-xs text-stone-600 font-medium">
                  Looking for the top beauty parlour, bridal makeup artist, or nail salon near {activeArea}? Anushka Beauty Parlour is just a short drive away at B-57 New Gupta Colony!
                </p>
              </div>

              <button
                onClick={() => openDirections(PARLOUR_INFO.mapsUrl)}
                className="shrink-0 flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] via-[#E8C15A] to-[#B8860B] hover:from-[#DFC04E] hover:to-[#A37409] text-stone-950 font-bold text-xs transition-all shadow-xs cursor-pointer"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Get Route from {activeArea}</span>
              </button>
            </div>
          )}
        </div>

        {/* SEO Keywords Showcase */}
        <div className="p-6 sm:p-8 rounded-2xl cream-card space-y-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-[#784A0E] text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-[#B8860B]" />
              <span>Trending Search Specializations & SEO Highlights</span>
            </div>
            <h3 className="font-heading text-xl sm:text-2xl font-bold text-stone-900">
              Popular Searches & Services in North Delhi
            </h3>
            <p className="text-stone-600 text-xs sm:text-sm font-medium">
              Anushka Beauty Parlour is optimized to deliver superior salon experiences across all highly-searched beauty categories:
            </p>
          </div>

          {/* Keyword tags cloud */}
          <div className="flex flex-wrap gap-2 sm:gap-2.5">
            {SEO_KEYWORDS.map((keyword, index) => (
              <a
                key={index}
                href={PARLOUR_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FAF6F0] border border-[#E8DEC8] hover:border-[#D4AF37] hover:bg-white text-stone-800 text-xs font-semibold transition-all shadow-2xs"
              >
                <CheckCircle2 className="w-3 h-3 text-[#B8860B]" />
                <span>{keyword}</span>
              </a>
            ))}
          </div>

          <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#ECE3D4] text-xs text-stone-600 leading-relaxed font-medium">
            <span className="font-bold text-[#784A0E]">SEO Local Note:</span> Whether you are searching for "bridal beauty makeup artist delhi", "nail salon near me", "best beauty parlour nearby us", or "hair kertaing and organic skin treatments", Anushka Beauty Parlour at B-57 New Gupta Colony provides certified, hygienic services for women with 100% genuine products.
          </div>
        </div>
      </div>
    </section>
  );
};
