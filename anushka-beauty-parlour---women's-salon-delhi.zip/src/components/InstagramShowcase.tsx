import React from 'react';
import { Instagram, Facebook, ExternalLink, CheckCircle2, Video, Heart, Sparkles, MessageCircle } from 'lucide-react';
import { INSTAGRAM_HIGHLIGHTS, PARLOUR_INFO } from '../data/parlourData';

export const InstagramShowcase: React.FC = () => {
  return (
    <section id="instagram-showcase" className="py-16 md:py-24 relative bg-[#F8F3EA] border-b border-[#ECE3D4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10 space-y-16">
        {/* Instagram Section */}
        <div>
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-pink-200 text-pink-900 font-semibold text-xs tracking-wider shadow-2xs">
              <Instagram className="w-3.5 h-3.5 text-pink-600" />
              Official Instagram Channel
            </div>

            <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-wider gold-shiny-text leading-tight">
              CONNECT WITH US ON INSTAGRAM
            </h2>

            {/* User's exact prompt note emphasized in cream & gold box */}
            <div className="p-5 sm:p-6 rounded-2xl bg-white border border-[#DFC899] shadow-sm max-w-2xl mx-auto">
              <p className="font-tagline text-3xl sm:text-4xl md:text-5xl gold-shiny-subtext mb-1">
                "On our instagram profile you can view our makeups, nail arts..."
              </p>
              <p className="text-stone-600 text-xs sm:text-sm font-medium">
                Follow <span className="text-pink-700 font-bold">{PARLOUR_INFO.instagramHandle}</span> for daily bridal transformations, trendy nail art designs, real client before-and-afters, and seasonal offers!
              </p>
            </div>

            <div className="pt-2">
              <a
                href={PARLOUR_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full bg-gradient-to-r from-pink-600 via-rose-500 to-amber-600 hover:from-pink-500 hover:to-amber-500 text-white font-bold text-sm shadow-md shadow-pink-950/15 hover:scale-105 active:scale-95 transition-all"
              >
                <Instagram className="w-4 h-4 text-white" />
                <span>Visit @anushka_beauty_parlou on Instagram</span>
                <ExternalLink className="w-4 h-4 ml-1 opacity-90" />
              </a>
            </div>
          </div>

          {/* Instagram Grid Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
            {INSTAGRAM_HIGHLIGHTS.map((item) => (
              <a
                key={item.id}
                href={PARLOUR_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative rounded-xl overflow-hidden aspect-square bg-stone-100 border border-[#E8DEC8] hover:border-[#D4AF37] shadow-sm block"
              >
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  loading="lazy"
                />

                {/* Instagram Hover Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-3 flex flex-col justify-end text-left">
                  <span className="text-[10px] uppercase font-bold text-pink-300 tracking-wider">
                    {item.category}
                  </span>
                  <p className="text-xs font-bold text-white leading-tight mt-0.5 line-clamp-1">
                    {item.title}
                  </p>
                  <p className="text-[10px] text-stone-200 line-clamp-1 mt-0.5">
                    {item.caption}
                  </p>
                  <div className="flex items-center gap-1.5 mt-2 text-[10px] text-pink-300 font-semibold">
                    <Instagram className="w-3 h-3" />
                    <span>View on Instagram</span>
                  </div>
                </div>

                {/* Little corner Instagram icon badge */}
                <div className="absolute top-2 right-2 p-1.5 rounded-full bg-white/80 backdrop-blur-sm text-pink-700 shadow-xs group-hover:hidden">
                  <Instagram className="w-3 h-3" />
                </div>
              </a>
            ))}
          </div>

          {/* Sub-note */}
          <div className="mt-6 text-center">
            <p className="text-xs text-stone-600 font-medium">
              Have a dream nail design or bridal inspiration from Instagram or Pinterest? Bring it to Anushka Beauty Parlour and our artists will replicate it flawlessly for you!
            </p>
          </div>
        </div>

        {/* Facebook Profile Showcase (Positioned directly below the Instagram page) */}
        <div className="relative pt-8 border-t-2 border-[#E5DAC6]">
          <div className="rounded-3xl cream-card p-6 sm:p-8 lg:p-10 relative overflow-hidden bg-white shadow-xl shadow-amber-950/5">
            {/* Ambient blue and gold subtle corner gradient */}
            <div className="absolute -top-16 -right-16 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
              {/* Left Column: Brand details & description */}
              <div className="space-y-4 text-center lg:text-left max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-800 font-bold text-xs tracking-wider shadow-2xs">
                  <Facebook className="w-3.5 h-3.5 text-[#1877F2] fill-[#1877F2]" />
                  Official Facebook Profile & Community
                </div>

                <div className="space-y-1">
                  <h3 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-black text-stone-900 tracking-tight">
                    CONNECT WITH US ON <span className="text-[#1877F2]">FACEBOOK</span>
                  </h3>
                  <p className="font-tagline text-2xl sm:text-3xl gold-shiny-subtext">
                    Join our beauty community & stay updated
                  </p>
                </div>

                <p className="text-stone-600 text-xs sm:text-sm leading-relaxed font-medium">
                  Stay connected with <strong className="text-stone-900">Anushka Beauty Parlour</strong> on Facebook for the latest bridal makeover reels, client reviews, festival specials, before & after transformations, and salon updates from B-57 New Gupta Colony, North Delhi.
                </p>

                {/* Highlights pill tags */}
                <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 pt-1 text-xs">
                  <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF7F2] border border-[#E8DEC8] text-stone-700 font-semibold">
                    <Video className="w-3 h-3 text-[#1877F2]" />
                    Client Videos & Reels
                  </span>
                  <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF7F2] border border-[#E8DEC8] text-stone-700 font-semibold">
                    <Sparkles className="w-3 h-3 text-[#B8860B]" />
                    Bridal Transformations
                  </span>
                  <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF7F2] border border-[#E8DEC8] text-stone-700 font-semibold">
                    <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
                    Women's Only Reviews
                  </span>
                </div>
              </div>

              {/* Right Column: Facebook Profile Card & CTA */}
              <div className="w-full lg:w-auto shrink-0 flex flex-col items-center sm:items-stretch gap-3">
                <div className="p-5 rounded-2xl bg-[#FAF7F2] border border-[#DFC899] text-center space-y-3 min-w-[280px] sm:min-w-[320px]">
                  <div className="w-14 h-14 rounded-2xl bg-[#1877F2] text-white flex items-center justify-center mx-auto shadow-md shadow-blue-600/30">
                    <Facebook className="w-8 h-8 fill-white" />
                  </div>
                  <div>
                    <h4 className="font-heading text-lg font-bold text-stone-900">
                      Anushka Beauty Parlour
                    </h4>
                    <p className="text-xs text-blue-700 font-semibold">
                      facebook.com/share/1HNLdm4zsU/
                    </p>
                    <p className="text-[11px] text-stone-500 mt-1">
                      B-57 New Gupta Colony, North Delhi
                    </p>
                  </div>

                  <a
                    href={PARLOUR_INFO.facebookUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-[#1877F2] hover:bg-[#166fe5] text-white font-bold text-sm shadow-md shadow-blue-700/20 hover:scale-102 active:scale-98 transition-all"
                    title="Open Anushka Beauty Parlour on Facebook"
                  >
                    <Facebook className="w-4 h-4 fill-white" />
                    <span>Visit Facebook Profile</span>
                    <ExternalLink className="w-3.5 h-3.5 ml-0.5 opacity-90" />
                  </a>
                </div>

                <div className="flex items-center justify-center gap-2 text-[11px] text-stone-500 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Verified Official Social Channel</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
