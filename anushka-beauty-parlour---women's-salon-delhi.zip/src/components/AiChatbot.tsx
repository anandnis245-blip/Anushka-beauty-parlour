import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, X, Send, Bot, User, Phone, MessageCircle, RefreshCw } from 'lucide-react';
import { PARLOUR_INFO } from '../data/parlourData';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

const INITIAL_MESSAGES: Message[] = [
  {
    id: 'welcome-1',
    role: 'model',
    text: `Namaste & Welcome to **Anushka Beauty Parlour**! ✨
*The salon for your beauty* (Exclusive Women's Parlour).

We are located at **B-57 New Gupta Colony, North Delhi** and open daily from **10:00 AM to 8:30 PM**.

How may I assist your beauty journey today? You can ask me about:
• HD & Airbrush Bridal Makeups
• Designer Nail Arts & Gel Extensions
• Glowing Skin Treatments & Facials
• Hair Keratin, Spa & Hair Designs
• Timings & Directions`,
    timestamp: 'Just now',
  },
];

const SUGGESTIONS = [
  'Bridal Makeup options',
  'Designer Nail Arts & Extensions',
  'Skin Glow Treatments & Cleanups',
  'Hair Keratin & Smoothening',
  'Address & Timings',
];

interface AiChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
}

export const AiChatbot: React.FC<AiChatbotProps> = ({ isOpen, onClose, initialQuery }) => {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const initialSentRef = useRef<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      if (initialQuery && initialSentRef.current !== initialQuery) {
        initialSentRef.current = initialQuery;
        handleSend(initialQuery);
      }
    }
  }, [messages, isOpen, initialQuery]);

  const handleSend = async (messageText: string) => {
    const textToSend = messageText.trim();
    if (!textToSend || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: messages.map((m) => ({ role: m.role, text: m.text })),
        }),
      });

      const data = await response.json();

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: data.reply || data.error || 'Thank you for reaching out! Please call us at 9278637482 for instant details.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: 'Welcome to Anushka Beauty Parlour! We are located at B-57 New Gupta Colony and open daily 10 AM to 8:30 PM. For instant consultation, call or WhatsApp us on 9278637482.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setMessages(INITIAL_MESSAGES);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      {/* Click backdrop to close */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Chat Window in Cream & Gold Luxury Style */}
      <div className="relative w-full sm:max-w-lg h-[92vh] sm:h-[620px] bg-[#FFFDF9] border border-[#DFC899] sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden z-10 shadow-amber-950/20">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#FAF5EC] via-[#F4EBD9] to-[#FAF5EC] border-b border-[#E8DEC8] p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10 rounded-full bg-gradient-to-tr from-[#D4AF37] to-[#F3CE72] p-[1.5px] shadow-sm shrink-0">
              <div className="w-full h-full bg-white rounded-full flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-[#B8860B]" />
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-heading text-sm font-black gold-shiny-text">
                  Anushka AI Beauty Assistant
                </h3>
                <span className="px-1.5 py-0.2 rounded bg-amber-100 border border-[#DFC899] text-[#784A0E] text-[10px] font-bold">
                  Women's Parlour
                </span>
              </div>
              <p className="text-[11px] text-stone-600 font-medium">
                Online • B-57 New Gupta Colony • 10 AM - 8:30 PM
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handleReset}
              className="p-1.5 rounded-lg text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 transition-colors cursor-pointer"
              title="Restart chat"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 transition-colors cursor-pointer"
              title="Close chat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quick action bar inside chat */}
        <div className="bg-[#FAF7F2] border-b border-[#ECE3D4] px-4 py-2 flex items-center justify-between text-xs text-stone-700">
          <div className="flex items-center gap-2">
            <a
              href={`tel:${PARLOUR_INFO.phone}`}
              className="flex items-center gap-1 text-[#784A0E] hover:text-[#4A2D05] font-bold"
            >
              <Phone className="w-3 h-3 text-[#B8860B]" />
              <span>{PARLOUR_INFO.phone}</span>
            </a>
          </div>
          <a
            href={PARLOUR_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-bold"
          >
            <MessageCircle className="w-3 h-3" />
            <span>Open in WhatsApp</span>
          </a>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#FFFDF9]">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${
                msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'
              }`}
            >
              <div
                className={`w-7 h-7 rounded-full shrink-0 flex items-center justify-center text-xs font-bold ${
                  msg.role === 'user'
                    ? 'bg-[#B8860B] text-white'
                    : 'bg-amber-100 text-[#784A0E] border border-[#DFC899]'
                }`}
              >
                {msg.role === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div
                className={`max-w-[82%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed shadow-xs ${
                  msg.role === 'user'
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-white font-medium rounded-tr-none'
                    : 'bg-[#FAF7F2] border border-[#ECE3D4] text-stone-800 rounded-tl-none space-y-1'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>
                <div
                  className={`text-[10px] mt-1 text-right ${
                    msg.role === 'user' ? 'text-amber-100' : 'text-stone-500'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-full bg-amber-100 text-[#784A0E] border border-[#DFC899] flex items-center justify-center">
                <Bot className="w-3.5 h-3.5 animate-spin" />
              </div>
              <div className="bg-[#FAF7F2] border border-[#ECE3D4] text-[#784A0E] text-xs px-4 py-2.5 rounded-2xl rounded-tl-none flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#B8860B] animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-[#B8860B] animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-[#B8860B] animate-bounce [animation-delay:0.4s]" />
                <span className="text-[11px] text-stone-600 ml-1 font-medium">Consulting beauty expert...</span>
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Suggestion Chips */}
        <div className="px-3 py-2 bg-[#FAF7F2] border-t border-[#ECE3D4] overflow-x-auto flex gap-1.5 scrollbar-none">
          {SUGGESTIONS.map((item, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(item)}
              className="shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-white border border-[#E8DEC8] text-[#784A0E] hover:border-[#D4AF37] hover:bg-amber-50 transition-colors whitespace-nowrap cursor-pointer font-semibold shadow-2xs"
            >
              {item}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend(input);
          }}
          className="p-3 bg-[#FAF7F2] border-t border-[#ECE3D4] flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about bridal makeup, nail art, treatments..."
            className="flex-1 bg-white border border-[#E8DEC8] focus:border-[#D4AF37] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none"
            disabled={loading}
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#DFC04E] hover:to-[#A37409] text-white font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-sm cursor-pointer"
            title="Send Message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
