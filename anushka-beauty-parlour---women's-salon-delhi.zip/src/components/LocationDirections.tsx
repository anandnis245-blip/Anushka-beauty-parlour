import React, { useState } from 'react';
import { MapPin, Navigation, Clock, Phone, MessageCircle, ExternalLink, ShieldCheck, Car, Train } from 'lucide-react';
import { PARLOUR_INFO } from '../data/parlourData';
import { openDirections, getParlourStatus } from '../utils/timeHelper';

export const LocationDirections: React.FC = () => {
  const [isLocating, setIsLocating] = useState(false);
  const status = getParlourStatus();

  const handleGetDirections = () => {
    setIsLocating(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setIsLocating(false);
          const { latitude, longitude } = pos.coords;
          const url = `https://www.google.com/maps/dir/?api=1&origin=${latitude},${longitude}&destination=B-57+New+Gupta+Colony+Delhi+110009`;
          window.open(url, '_blank', 'noopener,noreferrer');
        },
        () => {
          setIsLocating(false);
          window.open(PARLOUR_INFO.mapsUrl, '_blank', 'noopener,noreferrer');
        },
        { timeout: 7000 }
      );
    } else {
      setIsLocating(false);
      window.open(PARLOUR_INFO.mapsUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <section id="location-directions" className="py-16 md:py-24 relative bg-[#FAF6F0] border-b border-[#ECE3D4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-[#DFC899] text-[#784A0E] font-semibold text-xs uppercase tracking-widest shadow-2xs">
            <MapPin className="w-3.5 h-3.5 text-[#B8860B]" />
            Visit Our Salon
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-wider gold-shiny-text leading-tight">
            LOCATION & DIRECTIONS
          </h2>

          <p className="font-tagline text-3xl sm:text-4xl md:text-5xl gold-shiny-subtext pt-1">
            B-57 New Gupta Colony • Exclusively for Women
          </p>

          <p className="text-stone-600 text-sm sm:text-base max-w-2xl mx-auto font-medium">
            Conveniently situated in North Delhi, easily reachable from Model Town, Vijay Nagar, GTB Nagar Metro, and Delhi University North Campus.
          </p>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Address, Hours, Contact & Route Buttons (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            {/* Address & Timings Card */}
            <div className="p-6 sm:p-8 rounded-2xl cream-card space-y-6">
              {/* Address Block */}
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-amber-50 border border-[#DFC899] flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-[#B8860B]" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#8C5810] uppercase tracking-wider">
                      Official Address
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-amber-50 text-[#784A0E] border border-[#DFC899] text-[10px] font-bold">
                      Women's Parlour
                    </span>
                  </div>
                  <h3 className="font-heading text-xl sm:text-2xl font-bold text-stone-900">
                    B-57 New Gupta Colony
                  </h3>
                  <p className="text-stone-600 text-sm font-medium">
                    North Delhi, Delhi – 110009 (Near Model Town & GTB Nagar)
                  </p>
                </div>
              </div>

              {/* Operating Hours Block */}
              <div className="flex items-start gap-4 pt-4 border-t border-[#ECE3D4]">
                <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6 text-emerald-700" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                      Parlour Timings
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100/70 text-emerald-800 text-[10px] font-bold">
                      {status.statusText}
                    </span>
                  </div>
                  <p className="font-heading text-lg font-bold text-stone-900">
                    Open All Day from 10:00 AM – 8:30 PM
                  </p>
                  <p className="text-stone-600 text-xs sm:text-sm font-medium">
                    Monday to Sunday (Open all 7 days for your convenience)
                  </p>
                </div>
              </div>

              {/* Contact Details with Call & WhatsApp Links */}
              <div className="pt-4 border-t border-[#ECE3D4] space-y-3">
                <p className="text-xs font-bold text-[#8C5810] uppercase tracking-wider">
                  Direct Phone & Instant Connect:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <a
                    href={`tel:${PARLOUR_INFO.phone}`}
                    className="flex items-center justify-center gap-2.5 py-3 px-4 rounded-xl bg-white border border-[#DFC899] hover:border-[#B8860B] text-[#784A0E] font-bold text-sm shadow-xs transition-all group"
                  >
                    <Phone className="w-4 h-4 text-[#B8860B] group-hover:animate-bounce" />
                    <span>Call: {PARLOUR_INFO.phone}</span>
                  </a>

                  <a
                    href={PARLOUR_INFO.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2.5 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-sm shadow-xs transition-all"
                  >
                    <MessageCircle className="w-4 h-4 fill-white/20" />
                    <span>WhatsApp Chat</span>
                  </a>
                </div>
              </div>

              {/* Directions from Current Location Buttons */}
              <div className="pt-4 border-t border-[#ECE3D4] space-y-2">
                <button
                  onClick={handleGetDirections}
                  disabled={isLocating}
                  className="w-full flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] via-[#E8C15A] to-[#B8860B] hover:from-[#DFC04E] hover:to-[#A37409] text-stone-950 font-bold text-sm shadow-md shadow-amber-950/10 transition-all cursor-pointer"
                >
                  <Navigation className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
                  <span>
                    {isLocating
                      ? 'Fetching your location for route...'
                      : 'Get Direction on Google Map from My Current Location'}
                  </span>
                </button>

                <a
                  href={PARLOUR_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2 px-4 text-xs text-[#784A0E] hover:text-[#4A2D05] font-semibold transition-colors"
                >
                  <span>Open direct Google Maps link: maps.app.goo.gl/9yVNxjCmQPhPZNYP8</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Public Transport & Landmarks Tips */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl cream-card space-y-1.5">
                <div className="flex items-center gap-2 text-[#784A0E] text-xs font-bold">
                  <Train className="w-4 h-4 text-[#B8860B]" />
                  <span>Nearest Metro Stations</span>
                </div>
                <p className="text-xs text-stone-600 font-medium">
                  GTB Nagar Metro Station (1.8 km) and Model Town Metro Station (1.2 km) on Delhi Metro Yellow Line.
                </p>
              </div>

              <div className="p-4 rounded-xl cream-card space-y-1.5">
                <div className="flex items-center gap-2 text-[#784A0E] text-xs font-bold">
                  <Car className="w-4 h-4 text-[#B8860B]" />
                  <span>Cab / Auto Landmarks</span>
                </div>
                <p className="text-xs text-stone-600 font-medium">
                  Easy cab pick-and-drop right at B-57 New Gupta Colony, North Delhi. Ample parking space available.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Google Maps Interactive Preview (6 cols) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="rounded-2xl overflow-hidden border border-[#E8DEC8] shadow-md bg-white relative">
              {/* Map header banner */}
              <div className="bg-[#FAF6F0] px-4 py-3 border-b border-[#ECE3D4] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold text-stone-800">
                    Live Location Pin: B-57 New Gupta Colony
                  </span>
                </div>
                <a
                  href={PARLOUR_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-bold text-[#784A0E] hover:text-[#4A2D05] flex items-center gap-1"
                >
                  <span>Expand Map</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Embedded interactive Google Map preview for Delhi New Gupta Colony */}
              <div className="relative h-96 w-full bg-stone-100">
                <iframe
                  title="Anushka Beauty Parlour Map Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14002.502844855914!2d77.195!3d28.694!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd80e1cbb3ad%3A0xb36338ad7c6f0595!2sNew%20Gupta%20Colony%2C%20Delhi%2C%20110009!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                  className="w-full h-full border-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />

                {/* Floating overlay on map */}
                <div className="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-white/95 backdrop-blur-md border border-[#DFC899] shadow-md flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center shrink-0 border border-[#DFC899]">
                      <MapPin className="w-4 h-4 text-[#B8860B]" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-stone-900">Anushka Beauty Parlour</p>
                      <p className="text-[11px] text-stone-600">B-57 New Gupta Colony, North Delhi</p>
                    </div>
                  </div>

                  <a
                    href={PARLOUR_INFO.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#DFC04E] hover:to-[#A37409] text-stone-950 text-xs font-bold whitespace-nowrap shadow-xs"
                  >
                    Open Map App
                  </a>
                </div>
              </div>
            </div>

            {/* Women's Safety & Comfort Guarantee */}
            <div className="p-4 rounded-xl bg-white border border-[#E8DEC8] flex items-center gap-3 shadow-xs">
              <ShieldCheck className="w-5 h-5 text-[#B8860B] shrink-0" />
              <p className="text-xs text-stone-600 font-medium">
                <span className="font-bold text-[#784A0E]">Women-Only Comfort Zone:</span> Private, peaceful, and respectful atmosphere tailored exclusively for women's beauty care and relaxation.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
