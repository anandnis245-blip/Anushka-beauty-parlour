import React from 'react';
import { Phone, MessageCircle, Navigation, Sparkles, Search, Instagram, Facebook } from 'lucide-react';
import { PARLOUR_INFO } from '../data/parlourData';
import { openDirections } from '../utils/timeHelper';

interface MobileQuickBarProps {
  onOpenChat: () => void;
  onOpenSearch: () => void;
}

export const MobileQuickBar: React.FC<MobileQuickBarProps> = ({ onOpenChat, onOpenSearch }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 lg:hidden bg-[#FFFDF9]/98 backdrop-blur-lg border-t border-[#E8DEC8] px-2 sm:px-3 py-1.5 shadow-xl shadow-amber-950/15">
      {/* Quick Profile Social Tab Box: WhatsApp, Instagram & Facebook */}
      <div className="flex items-center justify-between gap-1.5 pb-1.5 mb-1.5 border-b border-[#ECE3D4] text-[10px] font-bold max-w-md mx-auto">
        <a
          href={PARLOUR_INFO.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1 py-1 px-1.5 rounded-lg bg-emerald-600 text-white shadow-2xs active:scale-95 transition-transform"
          title="WhatsApp"
        >
          <MessageCircle className="w-3 h-3 fill-white/20" />
          <span>WhatsApp</span>
        </a>
        <a
          href={PARLOUR_INFO.instagramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1 py-1 px-1.5 rounded-lg bg-gradient-to-r from-pink-600 via-rose-500 to-amber-600 text-white shadow-2xs active:scale-95 transition-transform"
          title="Instagram"
        >
          <Instagram className="w-3 h-3" />
          <span>Instagram</span>
        </a>
        <a
          href={PARLOUR_INFO.facebookUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1 py-1 px-1.5 rounded-lg bg-[#1877F2] text-white shadow-2xs active:scale-95 transition-transform"
          title="Facebook"
        >
          <Facebook className="w-3 h-3 fill-white" />
          <span>Facebook</span>
        </a>
      </div>

      <div className="grid grid-cols-5 gap-1.5 text-center max-w-md mx-auto">
        {/* Search */}
        <button
          onClick={onOpenSearch}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-amber-50/80 border border-[#DFC899] text-[#784A0E] active:scale-95 transition-all shadow-2xs font-semibold cursor-pointer"
        >
          <Search className="w-4 h-4 text-[#B8860B] mb-0.5" />
          <span className="text-[10px]">Search</span>
        </button>

        {/* Call Now */}
        <a
          href={`tel:${PARLOUR_INFO.phone}`}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-white border border-[#DFC899] text-[#784A0E] active:scale-95 transition-all shadow-2xs"
        >
          <Phone className="w-4 h-4 text-[#B8860B] mb-0.5 fill-[#B8860B]/20" />
          <span className="text-[10px] font-bold">Call</span>
        </a>

        {/* WhatsApp */}
        <a
          href={PARLOUR_INFO.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-emerald-600 text-white font-bold active:scale-95 transition-all shadow-md shadow-emerald-950/30"
        >
          <MessageCircle className="w-4 h-4 fill-white/20 mb-0.5" />
          <span className="text-[10px]">WhatsApp</span>
        </a>

        {/* Directions */}
        <button
          onClick={() => openDirections(PARLOUR_INFO.mapsUrl)}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-white border border-[#DFC899] text-stone-800 active:scale-95 transition-all cursor-pointer shadow-2xs font-medium"
        >
          <Navigation className="w-4 h-4 text-[#B8860B] mb-0.5" />
          <span className="text-[10px] font-semibold">Route</span>
        </button>

        {/* AI Assistant */}
        <button
          onClick={onOpenChat}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-stone-950 font-bold active:scale-95 transition-all cursor-pointer shadow-sm"
        >
          <Sparkles className="w-4 h-4 mb-0.5" />
          <span className="text-[10px]">AI Bot</span>
        </button>
      </div>
    </div>
  );
};
