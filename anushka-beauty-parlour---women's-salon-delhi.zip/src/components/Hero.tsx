import React from 'react';
import {
  Phone,
  MessageCircle,
  MapPin,
  Sparkles,
  Navigation,
  Instagram,
  Facebook,
  Clock,
  ShieldCheck,
  Heart,
  Award,
  Search
} from 'lucide-react';
import { PARLOUR_INFO } from '../data/parlourData';
import { openDirections, getParlourStatus } from '../utils/timeHelper';

interface HeroProps {
  onOpenBooking: () => void;
  onOpenChat: () => void;
  onOpenSearch: (query?: string) => void;
  onOpenHours?: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onOpenBooking,
  onOpenChat,
  onOpenSearch,
  onOpenHours,
}) => {
  const status = getParlourStatus();

  return (
    <section className="relative overflow-hidden pt-8 pb-16 md:pt-14 md:pb-24 border-b border-[#ECE3D4] bg-[#FAF7F2]">
      {/* Lady Picture prominently infused into the Website Background Theme on the Left Side */}
      <div className="absolute top-0 left-0 w-full lg:w-3/5 h-full pointer-events-none select-none overflow-hidden z-0">
        <img
          src={PARLOUR_INFO.bgImage}
          alt="Anushka Beauty Parlour Ambience"
          className="w-full h-full object-cover object-left-top opacity-[0.38] md:opacity-[0.45] lg:opacity-[0.52] filter contrast-110 saturate-125"
        />
        {/* Smooth radial and directional gradient blend into the white-cream background towards right */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#FAF7F2]/75 to-[#FAF7F2]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#FAF7F2] via-transparent to-[#FAF7F2]/50" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#FAF7F2]/60 via-transparent to-[#FAF7F2]" />
      </div>

      {/* Background ambient warm cream and champagne gold glows */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-amber-200/25 blur-[130px] rounded-full pointer-events-none" />
      <div className="absolute top-10 right-10 w-96 h-96 bg-yellow-100/35 blur-[120px] rounded-full pointer-events-none" />

      {/* Subtle gold grid texture */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#B8860B 1.2px, transparent 1.2px)`,
          backgroundSize: '28px 28px',
        }}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10 text-center space-y-6">
        {/* Top badges: Women's Parlour, Location & Open Hours */}
        <div className="inline-flex flex-wrap items-center justify-center gap-2 p-1.5 rounded-full bg-white/95 border border-[#DFC899] backdrop-blur-md shadow-xs">
          <span className="flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-50 to-yellow-50 border border-[#DFC899] text-[#784A0E] font-bold text-xs uppercase tracking-wider shadow-2xs">
            <Heart className="w-3.5 h-3.5 fill-[#B8860B] text-[#B8860B]" />
            Women's Parlour Exclusively
          </span>
          <span className="text-stone-700 text-xs flex items-center gap-1 px-2 font-medium">
            <MapPin className="w-3.5 h-3.5 text-[#B8860B]" />
            B-57 New Gupta Colony
          </span>
          <button
            onClick={onOpenHours}
            className="flex items-center gap-1 text-emerald-800 text-xs px-2 border-l border-[#E5DAC6] font-bold hover:text-emerald-900 cursor-pointer"
            title="Click to view weekly open schedule"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <Clock className="w-3.5 h-3.5 text-emerald-600" />
            <span>Open All 7 Days: 10 AM – 8:30 PM</span>
          </button>
        </div>

        {/* Business Name with golden-yellow shiny style */}
        <div className="space-y-1 sm:space-y-2">
          <h1 className="font-title text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black uppercase tracking-wider gold-shiny-text leading-[1.08]">
            Anushka Beauty Parlour
          </h1>

          {/* Tagline in stylish font style with golden-yellow shiny colour */}
          <p className="font-tagline text-3xl sm:text-4xl md:text-5xl lg:text-6xl gold-shiny-subtext font-normal pt-1 pb-1 tracking-wide">
            The salon for your beauty
          </p>
        </div>

        {/* Subtitle description */}
        <p className="text-stone-700 text-sm sm:text-base md:text-lg max-w-2xl mx-auto leading-relaxed font-medium">
          Welcome to North Delhi's premier destination for bridal beauty, designer nail artistry, nourishing skin treatments, and professional hair designs. Handcrafted exclusively for women with gentle care and high-quality salon products.
        </p>

        {/* Centered Search Bar */}
        <div className="max-w-xl mx-auto pt-1">
          <div
            onClick={() => onOpenSearch()}
            className="group relative flex items-center gap-3 p-2.5 sm:p-3 rounded-2xl bg-white/95 border-2 border-[#DFC899] hover:border-[#B8860B] shadow-md shadow-amber-950/5 cursor-pointer transition-all hover:scale-[1.01]"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-50 border border-[#DFC899] flex items-center justify-center shrink-0 group-hover:bg-[#FAF6F0]">
              <Search className="w-4 h-4 text-[#B8860B]" />
            </div>
            <div className="flex-1 min-w-0 text-left">
              <p className="text-xs sm:text-sm text-stone-500 font-medium truncate">
                Search bridal makeup, nail art, keratin, facial cleanup...
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold text-[#8C5810] bg-amber-50 px-2.5 py-1 rounded-lg border border-[#DFC899]">
                <span>Search</span>
                <kbd className="text-[10px] text-stone-400 font-mono">⌘K</kbd>
              </span>
              <span className="sm:hidden text-xs font-bold text-[#8C5810]">
                Search
              </span>
            </div>
          </div>

          {/* Quick Search Tag Pills under Search */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 pt-2 text-xs">
            <span className="text-[11px] text-stone-500 font-semibold">Popular:</span>
            {['HD Bridal', 'Gel Extensions', 'Hair Keratin', 'Gold Facial', 'Saree Draping'].map((tag) => (
              <button
                key={tag}
                onClick={() => onOpenSearch(tag)}
                className="text-[11px] px-2.5 py-0.5 rounded-full bg-white/90 border border-[#E8DEC8] hover:border-[#D4AF37] hover:bg-amber-50/70 text-[#784A0E] font-medium transition-colors cursor-pointer"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Primary Action Buttons (Call, WhatsApp, Directions, Instagram) */}
        <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-3.5 pt-1">
          {/* Direct Call Sign */}
          <a
            href={`tel:${PARLOUR_INFO.phone}`}
            className="flex items-center gap-2 px-5 py-3 rounded-full bg-white border-2 border-[#D4AF37] text-[#784A0E] hover:text-[#5E3A06] hover:bg-[#FFFDF9] hover:border-[#B8860B] hover:scale-105 active:scale-95 transition-all text-sm font-bold shadow-md shadow-amber-950/5 group"
            title="Call 9278637482"
          >
            <span className="w-6 h-6 rounded-full bg-amber-50 flex items-center justify-center group-hover:bg-amber-100">
              <Phone className="w-3.5 h-3.5 text-[#B8860B] fill-[#B8860B]/20 animate-pulse" />
            </span>
            <span>Call: {PARLOUR_INFO.phone}</span>
          </a>

          {/* WhatsApp, Instagram & Facebook Social Tab Group */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-2.5 p-1 rounded-full bg-white/80 border border-[#DFC899] shadow-sm backdrop-blur-sm">
            {/* Direct WhatsApp Open Link */}
            <a
              href={PARLOUR_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-emerald-600 via-green-600 to-emerald-700 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-emerald-950/20 hover:scale-105 active:scale-95 transition-all"
              title="Direct WhatsApp open link"
            >
              <MessageCircle className="w-4 h-4 fill-white/20" />
              <span>WhatsApp</span>
            </a>

            {/* Instagram Profile Link beside WhatsApp */}
            <a
              href={PARLOUR_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-pink-600 via-rose-500 to-amber-600 hover:opacity-90 text-white font-bold text-xs sm:text-sm shadow-md shadow-pink-950/20 hover:scale-105 active:scale-95 transition-all"
              title="View Makeups & Nail Arts on Instagram (@anushka_beauty_parlou)"
            >
              <Instagram className="w-4 h-4 text-white" />
              <span>Instagram</span>
            </a>

            {/* Facebook Profile Link beside Instagram & WhatsApp */}
            <a
              href={PARLOUR_INFO.facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#1877F2] hover:bg-[#166fe5] text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-900/20 hover:scale-105 active:scale-95 transition-all"
              title="Visit Anushka Beauty Parlour on Facebook"
            >
              <Facebook className="w-4 h-4 fill-white" />
              <span>Facebook</span>
            </a>
          </div>

          {/* Google Maps Direction from user's current location */}
          <button
            onClick={() => openDirections(PARLOUR_INFO.mapsUrl)}
            className="flex items-center gap-2 px-4 py-3 rounded-full bg-white border border-[#DFC899] text-stone-800 hover:text-[#784A0E] hover:border-[#B8860B] hover:scale-105 active:scale-95 transition-all text-xs sm:text-sm font-semibold shadow-2xs cursor-pointer"
            title="Get directions from current location"
          >
            <Navigation className="w-4 h-4 text-[#B8860B]" />
            <span>Directions to Parlour</span>
          </button>
        </div>

        {/* Interactive AI Beauty Concierge Banner */}
        <div className="pt-1 flex justify-center">
          <button
            onClick={onOpenChat}
            className="inline-flex items-center gap-3 px-5 py-3 rounded-2xl bg-white/95 border border-[#DFC899] hover:border-[#D4AF37] hover:bg-[#FFFDF9] transition-all cursor-pointer group text-left max-w-xl shadow-xs"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#D4AF37] to-[#B8860B] flex items-center justify-center shrink-0 shadow-2xs">
              <Sparkles className="w-4 h-4 text-stone-950" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-[#784A0E] uppercase tracking-wider flex items-center gap-1.5">
                <span>AI Beauty Concierge Online</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              </p>
              <p className="text-xs text-stone-600 truncate">
                Ask about bridal packages, nail arts, cleanup, or skin treatments
              </p>
            </div>
            <span className="text-[#8C5810] text-xs font-bold shrink-0 underline group-hover:text-[#5E3A06]">
              Ask AI →
            </span>
          </button>
        </div>

        {/* Quick Trust Highlights Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-3 text-left max-w-4xl mx-auto">
          <div className="p-3 rounded-xl bg-white/90 border border-[#E8DEC8] shadow-2xs flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#B8860B] shrink-0" />
            <span className="text-[11px] sm:text-xs font-semibold text-stone-800">We care about your skin</span>
          </div>
          <div className="p-3 rounded-xl bg-white/90 border border-[#E8DEC8] shadow-2xs flex items-center gap-2">
            <Heart className="w-3.5 h-3.5 text-[#B8860B] shrink-0" />
            <span className="text-[11px] sm:text-xs font-semibold text-stone-800">We provide what you want</span>
          </div>
          <div className="p-3 rounded-xl bg-white/90 border border-[#E8DEC8] shadow-2xs flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-[#B8860B] shrink-0" />
            <span className="text-[11px] sm:text-xs font-semibold text-stone-800">Only high quality products</span>
          </div>
          <div className="p-3 rounded-xl bg-white/90 border border-[#E8DEC8] shadow-2xs flex items-center gap-2">
            <Award className="w-3.5 h-3.5 text-[#B8860B] shrink-0" />
            <span className="text-[11px] sm:text-xs font-semibold text-stone-800">Experienced Artists</span>
          </div>
        </div>
      </div>
    </section>
  );
};
