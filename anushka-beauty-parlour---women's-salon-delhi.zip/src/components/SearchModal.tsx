import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  Sparkles,
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  ArrowRight,
  HelpCircle,
  ExternalLink,
  Heart,
  RotateCcw
} from 'lucide-react';
import {
  SEARCHABLE_SERVICES,
  SearchableService,
  SALON_FAQS,
  SalonFaq,
  NEARBY_AREAS,
  NearbyArea,
  PARLOUR_INFO,
  FACILITIES,
  Facility
} from '../data/parlourData';
import { openDirections } from '../utils/timeHelper';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
  onSelectService?: (service: SearchableService) => void;
  onOpenChatWithQuery?: (query: string) => void;
}

const POPULAR_SEARCH_TERMS = [
  'HD Bridal Makeup',
  'Gel Nail Extensions',
  'Keratin Treatment',
  'Gold Facial Cleanup',
  'Model Town',
  'Saree Draping',
  'Hair Spa',
  'Detan Facial',
];

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  initialQuery = '',
  onSelectService,
  onOpenChatWithQuery,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [activeTab, setActiveTab] = useState<'all' | 'services' | 'areas' | 'faqs'>('all');
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load recent searches from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem('anushka_recent_searches');
      if (stored) {
        setRecentSearches(JSON.parse(stored));
      }
    } catch {
      // ignore
    }
  }, []);

  // Update query when initialQuery changes or modal opens
  useEffect(() => {
    if (isOpen) {
      if (initialQuery) {
        setQuery(initialQuery);
      }
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, initialQuery]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const saveRecentSearch = (searchTerm: string) => {
    const clean = searchTerm.trim();
    if (!clean || clean.length < 2) return;
    try {
      const updated = [clean, ...recentSearches.filter((s) => s.toLowerCase() !== clean.toLowerCase())].slice(0, 5);
      setRecentSearches(updated);
      localStorage.setItem('anushka_recent_searches', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleSelectRecent = (term: string) => {
    setQuery(term);
    saveRecentSearch(term);
  };

  const clearRecent = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem('anushka_recent_searches');
    } catch {
      // ignore
    }
  };

  if (!isOpen) return null;

  const normalized = query.trim().toLowerCase();

  // Filter Services
  const matchingServices: SearchableService[] = SEARCHABLE_SERVICES.filter((svc) => {
    if (!normalized) return true;
    return (
      svc.title.toLowerCase().includes(normalized) ||
      svc.category.toLowerCase().includes(normalized) ||
      svc.shortDesc.toLowerCase().includes(normalized) ||
      svc.idealFor.toLowerCase().includes(normalized) ||
      svc.keywords.some((k) => k.toLowerCase().includes(normalized)) ||
      svc.highlights.some((h) => h.toLowerCase().includes(normalized))
    );
  });

  // Filter Facilities
  const matchingFacilities: Facility[] = FACILITIES.filter((fac) => {
    if (!normalized) return false;
    return (
      fac.title.toLowerCase().includes(normalized) ||
      fac.shortDesc.toLowerCase().includes(normalized) ||
      fac.badge.toLowerCase().includes(normalized) ||
      fac.details.some((d) => d.toLowerCase().includes(normalized))
    );
  });

  // Filter Areas
  const matchingAreas: NearbyArea[] = NEARBY_AREAS.filter((area) => {
    if (!normalized) return false;
    return (
      area.name.toLowerCase().includes(normalized) ||
      area.highlight.toLowerCase().includes(normalized)
    );
  });

  // Filter FAQs
  const matchingFaqs: SalonFaq[] = SALON_FAQS.filter((faq) => {
    if (!normalized) return false;
    return (
      faq.question.toLowerCase().includes(normalized) ||
      faq.answer.toLowerCase().includes(normalized) ||
      faq.keywords.some((k) => k.toLowerCase().includes(normalized))
    );
  });

  const totalResults =
    matchingServices.length + matchingFacilities.length + matchingAreas.length + matchingFaqs.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-8 sm:pt-16 p-4 bg-stone-950/70 backdrop-blur-md animate-in fade-in duration-200">
      {/* Backdrop */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Main Search Container */}
      <div className="relative w-full max-w-3xl bg-[#FFFDF9] border border-[#DFC899] rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden z-10 shadow-amber-950/25">
        {/* Top Search Input Bar */}
        <div className="p-4 sm:p-5 border-b border-[#ECE3D4] bg-[#FAF7F2] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 border border-[#DFC899] flex items-center justify-center shrink-0">
            <Search className="w-5 h-5 text-[#B8860B]" />
          </div>

          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && query.trim()) {
                  saveRecentSearch(query);
                }
              }}
              placeholder="Search bridal makeups, nail art, keratin, facial cleanups, areas..."
              className="w-full bg-transparent text-stone-900 placeholder:text-stone-400 font-medium text-base sm:text-lg focus:outline-none"
            />
          </div>

          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 transition-colors cursor-pointer"
              title="Clear input"
            >
              <X className="w-4 h-4" />
            </button>
          )}

          <div className="hidden sm:flex items-center gap-1.5 border-l border-[#E5DAC6] pl-3 text-xs text-stone-600 font-semibold">
            <kbd className="px-1.5 py-0.5 rounded bg-white border border-stone-300 shadow-2xs text-[10px]">ESC</kbd>
            <span>to exit</span>
          </div>

          <button
            onClick={onClose}
            className="sm:hidden p-1.5 rounded-lg text-stone-500 hover:text-stone-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Filter Tabs */}
        <div className="px-4 py-2.5 bg-[#FAF7F2] border-b border-[#ECE3D4] flex items-center justify-between gap-2 overflow-x-auto scrollbar-none text-xs">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'all'
                  ? 'bg-[#B8860B] text-white shadow-xs'
                  : 'bg-white border border-[#E8DEC8] text-stone-700 hover:border-[#D4AF37]'
              }`}
            >
              All Matches ({totalResults})
            </button>
            <button
              onClick={() => setActiveTab('services')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'services'
                  ? 'bg-[#B8860B] text-white shadow-xs'
                  : 'bg-white border border-[#E8DEC8] text-stone-700 hover:border-[#D4AF37]'
              }`}
            >
              Services ({matchingServices.length})
            </button>
            <button
              onClick={() => setActiveTab('areas')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'areas'
                  ? 'bg-[#B8860B] text-white shadow-xs'
                  : 'bg-white border border-[#E8DEC8] text-stone-700 hover:border-[#D4AF37]'
              }`}
            >
              Areas Served ({matchingAreas.length})
            </button>
            <button
              onClick={() => setActiveTab('faqs')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'faqs'
                  ? 'bg-[#B8860B] text-white shadow-xs'
                  : 'bg-white border border-[#E8DEC8] text-stone-700 hover:border-[#D4AF37]'
              }`}
            >
              FAQs & Policy ({matchingFaqs.length})
            </button>
          </div>

          <div className="hidden md:flex items-center gap-1 text-[11px] text-[#8C5810] font-semibold shrink-0">
            <Heart className="w-3 h-3 fill-[#B8860B]" />
            <span>Exclusively Women's Parlour</span>
          </div>
        </div>

        {/* Suggestion Chips & Recent Searches (When query is empty or short) */}
        {!normalized && (
          <div className="p-4 sm:p-5 bg-white border-b border-[#ECE3D4] space-y-4">
            {recentSearches.length > 0 && (
              <div>
                <div className="flex items-center justify-between text-xs font-bold text-stone-500 uppercase tracking-wider mb-2">
                  <span className="flex items-center gap-1.5">
                    <RotateCcw className="w-3.5 h-3.5 text-stone-400" />
                    Recent Searches
                  </span>
                  <button
                    onClick={clearRecent}
                    className="text-stone-400 hover:text-stone-700 font-medium normal-case text-[11px] cursor-pointer"
                  >
                    Clear history
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((term, i) => (
                    <button
                      key={i}
                      onClick={() => handleSelectRecent(term)}
                      className="px-3 py-1 rounded-full bg-[#FAF7F2] border border-[#E8DEC8] text-stone-800 text-xs font-medium hover:border-[#B8860B] hover:bg-amber-50 cursor-pointer flex items-center gap-1.5 transition-colors"
                    >
                      <Search className="w-3 h-3 text-stone-400" />
                      <span>{term}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <p className="text-xs font-bold text-[#8C5810] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#B8860B]" />
                Popular Trending Searches
              </p>
              <div className="flex flex-wrap gap-2">
                {POPULAR_SEARCH_TERMS.map((term, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setQuery(term);
                      saveRecentSearch(term);
                    }}
                    className="px-3 py-1.5 rounded-full bg-white border border-[#DFC899] text-[#784A0E] text-xs font-semibold hover:bg-amber-50 hover:border-[#B8860B] shadow-2xs transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Search className="w-3 h-3 text-[#B8860B]" />
                    <span>{term}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Scrollable Results List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-6 bg-[#FFFDF9]">
          {/* 1. Services Matching */}
          {(activeTab === 'all' || activeTab === 'services') && matchingServices.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black uppercase tracking-wider gold-shiny-text flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#B8860B]" />
                  <span>Beauty Services & Treatments ({matchingServices.length})</span>
                </h4>
                <span className="text-[11px] text-stone-500 font-medium">Click to book or inquire</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {matchingServices.map((service) => (
                  <div
                    key={service.id}
                    className="p-3.5 rounded-xl border border-[#ECE3D4] bg-white hover:border-[#D4AF37] hover:shadow-md transition-all group flex flex-col justify-between"
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={service.imageUrl}
                        alt={service.title}
                        className="w-16 h-16 rounded-lg object-cover shrink-0 border border-stone-200"
                        loading="lazy"
                      />
                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded-full bg-amber-50 border border-[#DFC899] text-[#784A0E] text-[10px] font-bold truncate">
                            {service.category}
                          </span>
                          <span className="text-stone-400 text-[10px] flex items-center gap-1">
                            <Clock className="w-3 h-3 text-stone-400" />
                            {service.duration}
                          </span>
                        </div>
                        <h5 className="font-heading text-sm font-bold text-stone-900 group-hover:text-[#784A0E] transition-colors leading-tight line-clamp-1">
                          {service.title}
                        </h5>
                        <p className="text-[11px] text-stone-600 line-clamp-2 leading-relaxed">
                          {service.shortDesc}
                        </p>
                      </div>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-[#F2ECE1] flex items-center justify-between gap-2">
                      <a
                        href={`https://wa.me/91${PARLOUR_INFO.phone}?text=Hello%20Anushka%20Beauty%20Parlour%2C%20I%20searched%20for%20and%20want%20to%20consult%20about%20${encodeURIComponent(
                          service.title
                        )}.`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => saveRecentSearch(service.title)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow-xs transition-colors"
                      >
                        <MessageCircle className="w-3 h-3" />
                        <span>Book on WhatsApp</span>
                      </a>
                      <a
                        href={`tel:${PARLOUR_INFO.phone}`}
                        className="p-1.5 rounded-lg bg-white border border-[#DFC899] text-[#784A0E] hover:border-[#B8860B] transition-colors"
                        title="Call salon"
                      >
                        <Phone className="w-3.5 h-3.5 text-[#B8860B]" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 2. Nearby Areas Matching */}
          {(activeTab === 'all' || activeTab === 'areas') && matchingAreas.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider gold-shiny-text flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#B8860B]" />
                <span>Nearby Neighborhoods & Areas Served ({matchingAreas.length})</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {matchingAreas.map((area) => (
                  <div
                    key={area.name}
                    className="p-3 rounded-xl bg-white border border-[#ECE3D4] flex items-center justify-between gap-3 hover:border-[#D4AF37] transition-all"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-stone-900">{area.name}</span>
                        <span className="text-[10px] font-semibold text-[#8C5810] bg-amber-50 px-2 py-0.2 rounded-full border border-[#DFC899]">
                          {area.distance}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">{area.highlight}</p>
                    </div>

                    <button
                      onClick={() => openDirections(PARLOUR_INFO.mapsUrl)}
                      className="shrink-0 px-2.5 py-1.5 rounded-lg bg-[#FAF7F2] border border-[#DFC899] text-[#784A0E] hover:bg-amber-100 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <MapPin className="w-3 h-3 text-[#B8860B]" />
                      <span>Directions</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. FAQs Matching */}
          {(activeTab === 'all' || activeTab === 'faqs') && matchingFaqs.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider gold-shiny-text flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-[#B8860B]" />
                <span>Answers to Frequent Inquiries ({matchingFaqs.length})</span>
              </h4>

              <div className="space-y-2.5">
                {matchingFaqs.map((faq) => (
                  <div
                    key={faq.id}
                    className="p-3.5 rounded-xl bg-white border border-[#ECE3D4] space-y-1.5"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-bold text-[#8C5810] bg-amber-50 px-2 py-0.5 rounded border border-[#DFC899]">
                        {faq.category}
                      </span>
                      <h5 className="text-xs font-bold text-stone-900">{faq.question}</h5>
                    </div>
                    <p className="text-xs text-stone-600 leading-relaxed font-medium">
                      {faq.answer}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Empty Search State */}
          {totalResults === 0 && (
            <div className="py-12 px-4 text-center max-w-md mx-auto space-y-4">
              <div className="w-14 h-14 rounded-full bg-amber-50 border border-[#DFC899] flex items-center justify-center mx-auto text-[#B8860B]">
                <Search className="w-6 h-6 text-[#B8860B]" />
              </div>
              <div className="space-y-1">
                <h4 className="font-heading text-lg font-bold text-stone-900">
                  No direct matches for "{query}"
                </h4>
                <p className="text-xs text-stone-600">
                  We customize all bridal makeups, nail art designs, skin treatments, and hair care. Let our AI concierge or parlour staff assist you!
                </p>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
                <button
                  onClick={() => {
                    onClose();
                    onOpenChatWithQuery?.(query);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-stone-950 text-xs font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Ask Anushka AI about "{query}"</span>
                </button>

                <a
                  href={`https://wa.me/91${PARLOUR_INFO.phone}?text=Hello%20Anushka%20Beauty%20Parlour%2C%20I%20have%20an%20inquiry%20regarding%3A%20${encodeURIComponent(
                    query
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-xs"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Inquire on WhatsApp</span>
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer Quick Bar */}
        <div className="p-3.5 bg-[#FAF7F2] border-t border-[#ECE3D4] flex flex-wrap items-center justify-between gap-3 text-xs text-stone-600">
          <div className="flex items-center gap-2">
            <span className="font-bold text-stone-800">Anushka Beauty Parlour</span>
            <span>•</span>
            <span>B-57 New Gupta Colony</span>
            <span>•</span>
            <span className="text-emerald-700 font-bold">10 AM - 8:30 PM</span>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={`tel:${PARLOUR_INFO.phone}`}
              className="flex items-center gap-1 text-[#784A0E] font-bold hover:underline"
            >
              <Phone className="w-3 h-3 text-[#B8860B]" />
              <span>Call: {PARLOUR_INFO.phone}</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
