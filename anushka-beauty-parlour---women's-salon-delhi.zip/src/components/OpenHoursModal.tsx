import React from 'react';
import { X, Clock, Calendar, CheckCircle2, Phone, MessageCircle, MapPin, Heart, ShieldCheck } from 'lucide-react';
import { PARLOUR_INFO } from '../data/parlourData';
import { getParlourStatus } from '../utils/timeHelper';

interface OpenHoursModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBooking: () => void;
}

export const OpenHoursModal: React.FC<OpenHoursModalProps> = ({ isOpen, onClose, onOpenBooking }) => {
  if (!isOpen) return null;

  const status = getParlourStatus();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-[#FFFDF9] border border-[#DFC899] rounded-2xl shadow-2xl p-6 overflow-hidden z-10 space-y-5 shadow-amber-950/20">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#ECE3D4] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-50 border border-[#DFC899] flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5 text-[#B8860B]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-heading text-lg font-black gold-shiny-text">
                  Parlour Open Timings
                </h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  {status.statusText}
                </span>
              </div>
              <p className="text-xs text-stone-600 font-medium">
                Open All 7 Days • Monday to Sunday
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-500 hover:text-stone-900 hover:bg-stone-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Highlight Banner */}
        <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-50 via-yellow-50 to-amber-50 border border-[#DFC899] flex items-center justify-between gap-3">
          <div className="space-y-0.5">
            <p className="text-xs font-bold text-[#784A0E] uppercase tracking-wider">
              Operating Hours:
            </p>
            <p className="font-heading text-base font-bold text-stone-900">
              10:00 AM – 8:30 PM Every Day
            </p>
            <p className="text-[11px] text-stone-600">
              {status.detailText}
            </p>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-white border border-[#DFC899] text-center shrink-0 shadow-2xs">
            <span className="block text-[10px] font-bold text-stone-500 uppercase">Days</span>
            <span className="font-bold text-[#8C5810] text-sm">7 / 7</span>
          </div>
        </div>

        {/* 7-Day Schedule List */}
        <div className="space-y-2 border border-[#ECE3D4] rounded-xl p-3 bg-white">
          <p className="text-[11px] font-bold text-[#8C5810] uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-[#B8860B]" />
            Weekly Operational Hours
          </p>

          <div className="grid grid-cols-1 divide-y divide-[#F2ECE1] text-xs">
            {status.schedule.map((item, index) => (
              <div key={index} className="py-2 flex items-center justify-between">
                <span className="font-semibold text-stone-800">{item.day}</span>
                <div className="flex items-center gap-2">
                  <span className="text-stone-700 font-medium">{item.hours}</span>
                  <span className="text-emerald-700 text-[10px] font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    Open
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Women's Safety & Location Info */}
        <div className="p-3 rounded-xl bg-[#FAF7F2] border border-[#ECE3D4] flex items-start gap-2.5 text-xs text-stone-600">
          <ShieldCheck className="w-4 h-4 text-[#B8860B] shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-bold text-stone-800">
              Exclusively Women's Parlour at B-57 New Gupta Colony
            </p>
            <p className="text-[11px] leading-relaxed">
              Safe, private, hygienic air-conditioned cabins exclusively for female clients with certified female artists.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
          <a
            href={`tel:${PARLOUR_INFO.phone}`}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-white border border-[#DFC899] text-[#784A0E] hover:border-[#B8860B] font-bold text-xs shadow-xs"
          >
            <Phone className="w-4 h-4 text-[#B8860B]" />
            <span>Call: {PARLOUR_INFO.phone}</span>
          </a>

          <a
            href={PARLOUR_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xs"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Book on WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
};
