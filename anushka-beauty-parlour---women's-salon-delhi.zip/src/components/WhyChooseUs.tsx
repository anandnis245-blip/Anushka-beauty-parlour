import React from 'react';
import { Sparkles, HeartHandshake, ShieldCheck, Award, Heart, CheckCircle2 } from 'lucide-react';
import { WHY_CHOOSE_US, PARLOUR_INFO } from '../data/parlourData';

const iconMap = {
  Sparkles: Sparkles,
  HeartHandshake: HeartHandshake,
  ShieldCheck: ShieldCheck,
  Award: Award,
};

export const WhyChooseUs: React.FC = () => {
  return (
    <section id="why-choose-us" className="py-16 md:py-24 relative bg-[#FAF6F0] border-b border-[#ECE3D4]">
      {/* Background warm soft glow */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-amber-200/20 blur-[130px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-[#DFC899] text-[#784A0E] font-semibold text-xs uppercase tracking-widest shadow-2xs">
            <Heart className="w-3.5 h-3.5 fill-[#B8860B] text-[#B8860B]" />
            Our Core Commitment
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-wider gold-shiny-text leading-tight">
            WHY CHOOSE US?
          </h2>

          <p className="font-tagline text-3xl sm:text-4xl md:text-5xl gold-shiny-subtext pt-1">
            Dedicated to your beauty, wellness & confidence
          </p>

          <p className="text-stone-600 text-sm sm:text-base max-w-2xl mx-auto font-medium">
            At Anushka Beauty Parlour, we treat every client like family. Step into a relaxing, 100% women-friendly sanctuary where precision, care, and artistry unite.
          </p>
        </div>

        {/* 4 Core Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {WHY_CHOOSE_US.map((item, index) => {
            const IconComponent = iconMap[item.iconName as keyof typeof iconMap] || Sparkles;
            return (
              <div
                key={item.id}
                className="group relative p-6 sm:p-8 rounded-2xl cream-card transition-all duration-300 hover:-translate-y-1"
              >
                {/* Subtle gold foil accent */}
                <div className="absolute top-0 right-0 w-28 h-28 bg-amber-100/30 rounded-bl-full blur-xl group-hover:bg-amber-200/40 transition-all pointer-events-none" />

                <div className="flex items-start gap-4 sm:gap-5">
                  <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-[#D4AF37] via-[#F3CE72] to-[#B8860B] p-[1.5px] shrink-0 shadow-sm">
                    <div className="w-full h-full bg-[#FFFDF9] rounded-2xl flex items-center justify-center">
                      <IconComponent className="w-6 h-6 sm:w-7 sm:h-7 text-[#B8860B] group-hover:scale-110 transition-transform" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[#8C5810] font-bold text-xs uppercase tracking-wider">
                        Pillar 0{index + 1}
                      </span>
                      <span className="text-stone-300">•</span>
                      <span className="text-stone-500 text-xs font-medium">Exclusively for Women</span>
                    </div>

                    <h3 className="font-heading text-lg sm:text-xl font-bold text-stone-900 group-hover:text-[#784A0E] transition-colors">
                      {item.title}
                    </h3>

                    <p className="text-stone-600 text-sm leading-relaxed">
                      {item.description}
                    </p>

                    <div className="pt-2 flex items-center gap-1.5 text-xs text-[#8C5810] font-semibold">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#B8860B]" />
                      <span>Guaranteed hygiene & personalized attention</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Women's Exclusive Assurance Card in Cream & Gold */}
        <div className="mt-12 p-6 rounded-2xl bg-[#FFFDF9] border border-[#DFC899] flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center shrink-0 border border-[#DFC899]">
              <Heart className="w-6 h-6 text-[#B8860B] fill-[#B8860B]" />
            </div>
            <div>
              <h4 className="font-heading text-lg font-bold text-stone-900">
                100% Women-Only Sanctuary in New Gupta Colony
              </h4>
              <p className="text-stone-600 text-xs sm:text-sm">
                Clean, sanitized private cabins with complete privacy, female-only staff, and continuous comfort from 10:00 AM to 8:30 PM.
              </p>
            </div>
          </div>

          <a
            href={PARLOUR_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 px-6 py-2.5 rounded-full bg-gradient-to-r from-[#D4AF37] via-[#E8C15A] to-[#B8860B] hover:from-[#DFC04E] hover:to-[#A37409] text-stone-950 font-bold text-xs sm:text-sm transition-all shadow-sm"
          >
            Chat with Our Experts
          </a>
        </div>
      </div>
    </section>
  );
};
