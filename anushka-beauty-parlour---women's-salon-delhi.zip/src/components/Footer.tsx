import React from 'react';
import { Sparkles, Phone, MessageCircle, MapPin, Clock, Instagram, Facebook, Navigation, Heart } from 'lucide-react';
import { PARLOUR_INFO, SEO_KEYWORDS } from '../data/parlourData';
import { openDirections } from '../utils/timeHelper';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#F5EFE6] text-stone-700 border-t border-[#E5DAC6] pt-16 pb-24 lg:pb-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Top brand & details grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-[#E5DAC6]">
          {/* Col 1: Brand & Identity */}
          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#D4AF37] via-[#F3CE72] to-[#B8860B] p-[1.5px] shadow-2xs shrink-0">
                  <div className="w-full h-full bg-white rounded-full flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-[#B8860B]" />
                  </div>
                </div>
                <h3 className="font-title text-xl font-bold uppercase gold-shiny-text">
                  Anushka Beauty Parlour
                </h3>
              </div>
              <p className="font-tagline text-2xl gold-shiny-subtext ml-10">
                The salon for your beauty
              </p>
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-[#DFC899] text-[#784A0E] text-xs font-bold uppercase tracking-wider shadow-2xs">
              <Heart className="w-3 h-3 text-[#B8860B] fill-[#B8860B]" />
              Exclusive Women's Parlour
            </div>

            <p className="text-xs text-stone-600 leading-relaxed font-medium">
              We care about your skin and provide what you want with only high quality products and experienced professional makeup and nail artists.
            </p>

            <div className="flex items-center gap-2 pt-1">
              <a
                href={PARLOUR_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 rounded-full bg-white border border-[#DFC899] hover:border-pink-500 text-pink-700 hover:text-pink-800 transition-colors shadow-2xs"
                title="Instagram Profile"
              >
                <Instagram className="w-4 h-4" />
              </a>

              <a
                href={PARLOUR_INFO.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 rounded-full bg-white border border-[#DFC899] hover:border-blue-500 text-[#1877F2] hover:text-blue-700 transition-colors shadow-2xs"
                title="Facebook Profile"
              >
                <Facebook className="w-4 h-4 fill-[#1877F2]" />
              </a>

              <a
                href={PARLOUR_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 rounded-full bg-white border border-[#DFC899] hover:border-emerald-500 text-emerald-700 hover:text-emerald-800 transition-colors shadow-2xs"
                title="WhatsApp Direct"
              >
                <MessageCircle className="w-4 h-4" />
              </a>

              <a
                href={`tel:${PARLOUR_INFO.phone}`}
                className="p-2.5 rounded-full bg-white border border-[#DFC899] hover:border-[#B8860B] text-[#784A0E] hover:text-[#4A2D05] transition-colors shadow-2xs"
                title="Call 9278637482"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Services & Facilities */}
          <div className="space-y-3">
            <h4 className="font-heading text-sm font-black gold-shiny-text uppercase tracking-wider">
              Special Facilities
            </h4>
            <ul className="space-y-2 text-xs font-medium">
              <li>
                <a href="#facilities" className="hover:text-[#B8860B] transition-colors">
                  • Makeovers & Party Glam
                </a>
              </li>
              <li>
                <a href="#facilities" className="hover:text-[#B8860B] transition-colors">
                  • Bridal Makeups (HD & Airbrush)
                </a>
              </li>
              <li>
                <a href="#facilities" className="hover:text-[#B8860B] transition-colors">
                  • Many Skin Treatments & Hydration
                </a>
              </li>
              <li>
                <a href="#facilities" className="hover:text-[#B8860B] transition-colors">
                  • Beautiful Nail Arts & Treatments
                </a>
              </li>
              <li>
                <a href="#facilities" className="hover:text-[#B8860B] transition-colors">
                  • Facial Cleanup (Fruit, Gold & Herbal)
                </a>
              </li>
              <li>
                <a href="#facilities" className="hover:text-[#B8860B] transition-colors">
                  • Hair Care, Keratin & Hair Designs
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Address & Directions */}
          <div className="space-y-3">
            <h4 className="font-heading text-sm font-black gold-shiny-text uppercase tracking-wider">
              Address & Route
            </h4>
            <div className="space-y-2 text-xs text-stone-700 font-medium">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#B8860B] shrink-0 mt-0.5" />
                <span>
                  B-57 New Gupta Colony, North Delhi, Delhi 110009
                </span>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <span>Open All Day: 10:00 AM – 8:30 PM (All 7 Days)</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => openDirections(PARLOUR_INFO.mapsUrl)}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-white border border-[#DFC899] text-[#784A0E] hover:border-[#B8860B] text-xs font-bold cursor-pointer shadow-2xs"
              >
                <Navigation className="w-3.5 h-3.5 text-[#B8860B]" />
                <span>Directions on Google Maps</span>
              </button>
            </div>
          </div>

          {/* Col 4: Instagram & Direct Contact */}
          <div className="space-y-3">
            <h4 className="font-heading text-sm font-black gold-shiny-text uppercase tracking-wider">
              Contact & Portfolio
            </h4>
            <div className="space-y-2 text-xs">
              <a
                href={`tel:${PARLOUR_INFO.phone}`}
                className="flex items-center gap-2 text-[#784A0E] hover:underline font-bold text-sm"
              >
                <Phone className="w-4 h-4" />
                <span>{PARLOUR_INFO.phoneFormatted}</span>
              </a>

              <a
                href={PARLOUR_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="block p-3 rounded-xl bg-white border border-[#DFC899] text-stone-800 shadow-2xs hover:border-[#D4AF37]"
              >
                <p className="font-tagline text-lg gold-shiny-subtext">
                  On our instagram profile
                </p>
                <p className="text-[11px] text-pink-700 font-bold mt-0.5">
                  You can view our makeups, nail arts...
                </p>
                <span className="text-[10px] text-stone-500 flex items-center gap-1 mt-1 font-medium">
                  <Instagram className="w-3 h-3 text-pink-600" />
                  @anushka_beauty_parlou
                </span>
              </a>

              <a
                href={PARLOUR_INFO.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="block p-3 rounded-xl bg-white border border-[#DFC899] text-stone-800 shadow-2xs hover:border-[#1877F2] transition-colors"
              >
                <p className="font-tagline text-lg text-[#1877F2]">
                  Join us on Facebook
                </p>
                <p className="text-[11px] text-blue-800 font-bold mt-0.5">
                  Client transformation videos & offers
                </p>
                <span className="text-[10px] text-stone-500 flex items-center gap-1 mt-1 font-medium">
                  <Facebook className="w-3 h-3 text-[#1877F2] fill-[#1877F2]" />
                  Anushka Beauty Parlour
                </span>
              </a>
            </div>
          </div>
        </div>

        {/* SEO Keywords footer index */}
        <div className="py-6 border-b border-[#E5DAC6] text-[11px] text-stone-500 space-y-2">
          <p className="text-[#8C5810] font-bold uppercase tracking-wider text-[10px]">
            Targeted Services & SEO Directory:
          </p>
          <p className="leading-relaxed">
            {SEO_KEYWORDS.join(' • ')} • Areas Served: New Gupta Colony, Model Town, Vijay Nagar, GTB Nagar, Hudson Lane, Roop Nagar, Kamla Nagar, North Delhi, Shakti Nagar, Kingsway Camp, Civil Lines, Patel Chest.
          </p>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>© {new Date().getFullYear()} Anushka Beauty Parlour. All rights reserved. Strictly Women's Parlour.</p>
          <p className="flex items-center gap-1 text-stone-600 font-medium">
            <span>The salon for your beauty</span>
            <span className="text-[#B8860B]">•</span>
            <span>B-57 New Gupta Colony</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
