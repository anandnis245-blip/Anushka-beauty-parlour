import React, { useState } from 'react';
import { Sparkles, Check, MessageCircle, Phone, Heart, Eye } from 'lucide-react';
import { FACILITIES, Facility, PARLOUR_INFO } from '../data/parlourData';

export const Facilities: React.FC = () => {
  const [selectedFacility, setSelectedFacility] = useState<Facility | null>(null);

  return (
    <section id="facilities" className="py-16 md:py-24 relative bg-[#FAF7F2] border-b border-[#ECE3D4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-[#DFC899] text-[#784A0E] font-semibold text-xs uppercase tracking-widest shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-[#B8860B]" />
            Complete Beauty Services
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-wider gold-shiny-text leading-tight">
            OUR SPECIAL BEAUTY FACILITIES
          </h2>

          <p className="font-tagline text-3xl sm:text-4xl md:text-5xl gold-shiny-subtext pt-1">
            All kinds of beauty facilities available for women
          </p>

          <p className="text-stone-600 text-sm sm:text-base max-w-2xl mx-auto font-medium">
            From regal bridal makeovers to intricate designer nail extensions and therapeutic hair spa care, explore our signature offerings crafted to elevate your natural charm.
          </p>
        </div>

        {/* Facilities Grid with Pictures in Front of Them */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {FACILITIES.map((facility, idx) => (
            <div
              key={facility.id}
              className="group flex flex-col rounded-2xl cream-card overflow-hidden transition-all duration-300 hover:-translate-y-1.5"
            >
              {/* Picture in front of the facility details */}
              <div className="relative h-64 overflow-hidden bg-stone-100">
                <img
                  src={facility.imageUrl}
                  alt={facility.imageAlt}
                  className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700"
                  loading="lazy"
                />
                {/* Gradient overlay for text contrast */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />

                {/* Badge on picture */}
                <div className="absolute top-3 left-3">
                  <span className="px-3 py-1 rounded-full bg-white/95 backdrop-blur-md border border-[#DFC899] text-[#784A0E] text-xs font-bold shadow-sm">
                    {facility.badge}
                  </span>
                </div>

                {/* Quick inspect button */}
                <button
                  onClick={() => setSelectedFacility(facility)}
                  className="absolute bottom-3 right-3 p-2 rounded-full bg-white/85 hover:bg-white text-[#784A0E] backdrop-blur-sm border border-[#DFC899] transition-all opacity-90 group-hover:opacity-100 cursor-pointer shadow-sm"
                  title="View image details"
                >
                  <Eye className="w-4 h-4" />
                </button>
              </div>

              {/* Facility Details & Highlights in Light Cream Card */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4 bg-white">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[#8C5810] font-bold text-xs uppercase tracking-wider">
                      Facility 0{idx + 1}
                    </span>
                    <span className="text-stone-300">•</span>
                    <span className="text-emerald-700 text-xs font-bold">Available Daily</span>
                  </div>

                  <h3 className="font-heading text-xl font-bold text-stone-900 group-hover:text-[#784A0E] transition-colors">
                    {facility.title}
                  </h3>

                  <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
                    {facility.shortDesc}
                  </p>
                </div>

                {/* Sub-services / Detailed facilities breakdown */}
                <div className="space-y-2 pt-2 border-t border-[#ECE3D4]">
                  <p className="text-[11px] font-bold text-[#8C5810] uppercase tracking-wider">
                    Services Included:
                  </p>
                  <ul className="space-y-1.5">
                    {facility.details.map((detail, index) => (
                      <li key={index} className="flex items-start gap-2 text-xs text-stone-700 font-medium">
                        <Check className="w-3.5 h-3.5 text-[#B8860B] shrink-0 mt-0.5" />
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Inquiry CTA without prices as requested */}
                <div className="pt-3 border-t border-[#ECE3D4] flex items-center gap-2">
                  <a
                    href={`https://wa.me/91${PARLOUR_INFO.phone}?text=Hello%20Anushka%20Beauty%20Parlour%2C%20I%20want%20to%20know%20details%20and%20consult%20about%20${encodeURIComponent(
                      facility.title
                    )}.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-xs transition-all shadow-xs"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Inquire on WhatsApp</span>
                  </a>

                  <a
                    href={`tel:${PARLOUR_INFO.phone}`}
                    className="p-2.5 rounded-xl bg-white border border-[#DFC899] text-[#784A0E] hover:border-[#B8860B] hover:bg-[#FFFDF9] transition-all shadow-xs"
                    title="Call to book"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#B8860B]" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal for viewing detailed image */}
        {selectedFacility && (
          <div
            className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelectedFacility(null)}
          >
            <div
              className="bg-white border border-[#DFC899] rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl space-y-4 p-5"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative rounded-xl overflow-hidden aspect-video bg-black">
                <img
                  src={selectedFacility.imageUrl}
                  alt={selectedFacility.imageAlt}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <span className="text-[#8C5810] text-xs font-bold uppercase tracking-wider">
                  {selectedFacility.badge}
                </span>
                <h3 className="font-heading text-2xl font-bold text-stone-900 mt-1">
                  {selectedFacility.title}
                </h3>
                <p className="text-stone-600 text-sm mt-2 font-medium">{selectedFacility.shortDesc}</p>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  onClick={() => setSelectedFacility(null)}
                  className="px-4 py-2 rounded-xl bg-stone-100 text-stone-700 text-xs font-semibold hover:bg-stone-200 cursor-pointer"
                >
                  Close
                </button>
                <a
                  href={`https://wa.me/91${PARLOUR_INFO.phone}?text=Hello%20Anushka%20Beauty%20Parlour%2C%20I%20am%20interested%20in%20${encodeURIComponent(
                    selectedFacility.title
                  )}.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white text-xs font-bold flex items-center gap-2"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Book / Inquire on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
