import React, { useState } from 'react';
import { X, Sparkles, MessageCircle, User, Heart } from 'lucide-react';
import { FACILITIES, PARLOUR_INFO } from '../data/parlourData';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [service, setService] = useState('Bridal Makeups');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('11:00 AM');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const text = `Hello Anushka Beauty Parlour!
I would like to book an appointment/consultation:
- Name: ${name || 'Valued Client'}
- Service: ${service}
- Preferred Date: ${preferredDate || 'Earliest available'}
- Preferred Time: ${preferredTime}
${notes ? `- Note: ${notes}` : ''}
Looking forward to visiting B-57 New Gupta Colony!`;

    const url = `https://wa.me/91${PARLOUR_INFO.phone}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-[#FFFDF9] border border-[#DFC899] rounded-2xl shadow-2xl p-6 overflow-hidden z-10 space-y-5 shadow-amber-950/20">
        <div className="flex items-center justify-between border-b border-[#ECE3D4] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-50 border border-[#DFC899] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-[#B8860B]" />
            </div>
            <div>
              <h3 className="font-heading text-lg font-black gold-shiny-text">
                Book / Inquire Appointment
              </h3>
              <p className="text-[11px] text-stone-600 font-medium">
                Anushka Beauty Parlour • Women's Parlour
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-stone-500 hover:text-stone-900 hover:bg-stone-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">
              Your Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                className="w-full bg-[#FAF7F2] border border-[#E8DEC8] rounded-xl pl-9 pr-3 py-2.5 text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:border-[#D4AF37] focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">
              Select Facility / Service
            </label>
            <select
              value={service}
              onChange={(e) => setService(e.target.value)}
              className="w-full bg-[#FAF7F2] border border-[#E8DEC8] rounded-xl px-3 py-2.5 text-xs sm:text-sm text-stone-900 focus:border-[#D4AF37] focus:outline-none"
            >
              {FACILITIES.map((fac) => (
                <option key={fac.id} value={fac.title} className="bg-white text-stone-900">
                  {fac.title}
                </option>
              ))}
              <option value="Pre-Bridal Skincare & Draping" className="bg-white text-stone-900">
                Pre-Bridal Skincare & Draping
              </option>
              <option value="General Beauty Consultation" className="bg-white text-stone-900">
                General Beauty Consultation
              </option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                Preferred Date
              </label>
              <input
                type="date"
                value={preferredDate}
                onChange={(e) => setPreferredDate(e.target.value)}
                className="w-full bg-[#FAF7F2] border border-[#E8DEC8] rounded-xl px-3 py-2 text-xs text-stone-900 focus:border-[#D4AF37] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                Preferred Time
              </label>
              <select
                value={preferredTime}
                onChange={(e) => setPreferredTime(e.target.value)}
                className="w-full bg-[#FAF7F2] border border-[#E8DEC8] rounded-xl px-3 py-2 text-xs text-stone-900 focus:border-[#D4AF37] focus:outline-none"
              >
                <option value="10:30 AM">10:30 AM</option>
                <option value="12:00 PM">12:00 PM</option>
                <option value="02:00 PM">02:00 PM</option>
                <option value="04:30 PM">04:30 PM</option>
                <option value="06:30 PM">06:30 PM</option>
                <option value="07:30 PM">07:30 PM</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">
              Custom Requests / Notes (Optional)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Sangeet makeover, nail extension length, sensitive skin..."
              className="w-full bg-[#FAF7F2] border border-[#E8DEC8] rounded-xl px-3 py-2 text-xs text-stone-900 placeholder:text-stone-400 focus:border-[#D4AF37] focus:outline-none resize-none"
            />
          </div>

          <div className="p-2.5 rounded-xl bg-amber-50 border border-[#DFC899] text-[11px] text-[#784A0E] flex items-center gap-2 font-medium">
            <Heart className="w-4 h-4 text-[#B8860B] shrink-0" />
            <span>Open all 7 days from 10:00 AM to 8:30 PM at B-57 New Gupta Colony</span>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-green-600 to-emerald-700 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-emerald-950/20 cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>Send Booking on WhatsApp</span>
          </button>
        </form>
      </div>
    </div>
  );
};
